<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
});*/
Route::get('/cars', 'CarController@index');
Route::get('/cars/create', 'CarController@create');
Route::post('/create', 'CarController@store');
Route::delete('/cars/{car}', 'CarController@destroy');
Route::get('/cars/{car}/edit', 'CarController@edit');
Route::put('/cars/{car}', 'CarController@update');

Route::get('/E-SEHAT/login', 'SehatController@login');
Route::post('/UserRegister', 'SehatController@store');
Route::get('/E-SEHAT/UserRegister', 'SehatController@index');
Route::post('/login', 'SehatController@logs');

Route::get('/E-SEHAT/', 'SehatController@menu');
Route::get('/E-SEHAT/menu', 'SehatController@menu');
Route::get('/E-SEHAT/contact', 'SehatController@contact');
Route::post('/contact', 'ContactController@contactInfo');
Route::get('/E-SEHAT/nutrition', 'SehatController@nutrition');
Route::post('/nutrition', 'SehatController@parseImport');
Route::post('/diagonosis', 'SehatController@d_diagonosis');
Route::get('/E-SEHAT/diagonosis', 'SehatController@diagonosis');
Route::post('/diagonose1', 'SehatController@symdiagonosis');
Route::get('/E-SEHAT/diagonose1', 'SehatController@ddiagonosis');
Route::get('/E-SEHAT/symptoms', 'SehatController@symptoms');
Route::post('/symptoms', 'SehatController@showsymptoms');
Route::post('/results', 'SehatController@results');
Route::get('/E-SEHAT/showSymptoms', 'SehatController@symchecker');
Route::get('/E-SEHAT/log', 'SehatController@getLogout');
Route::get('/E-SEHAT/dietPlans', 'SehatController@dietPlans');
Route::get('/E-SEHAT/{result_ar}/symptomDetails', 'SehatController@details');
Route::get('/E-SEHAT/doctorProfile', 'SehatController@docProfile');
Route::get('/E-SEHAT/doctormenu', 'DoctorController@menu');
Route::get('/E-SEHAT/doctorcontact', 'DoctorController@contact');
Route::post('/doctorcontact', 'DoctorController@contactInfo');
Route::get('/E-SEHAT/doctorLogin', 'DoctorController@doctorLogin');
Route::post('/doctorLog', 'DoctorController@doctorlog');
Route::post('/profile', 'DoctorController@profile');
Route::get('/E-SEHAT/myprofile', 'DoctorController@showProfile');
Route::get('/E-SEHAT/editprofile', 'DoctorController@edit');
Route::post('/updateProfile', 'DoctorController@update');
Route::get('/E-SEHAT/doctors', 'SehatController@showDoc');
Route::get('/E-SEHAT/{id}/viewprofile', 'SehatController@viewprofile');
Route::get('/E-SEHAT/{id}/clinic', 'SehatController@clinic');
Route::get('/E-SEHAT/{id}/video', 'SehatController@video');
Route::post('/reviews', 'SehatController@reviews');
Route::get('/E-SEHAT/docReviews', 'DoctorController@reviews');
Route::get('/E-SEHAT/docClinic', 'DoctorController@viewClinic');
Route::get('/E-SEHAT/docVideo', 'DoctorController@viewVideo');
//Route::get('/E-SEHAT/{id}/bookclinic', 'SehatController@bookclinic');
//Route::get('/E-SEHAT/{id}/bookvideo', 'SehatController@bookvideo');
Route::post('/bookvideo', 'SehatController@bookvideo');
Route::post('/bookclinic', 'SehatController@bookclinic');

Route::get('/E-SEHAT/userProfile', 'SehatController@userprofile');
Route::get('/E-SEHAT/searchSpecialist', 'SehatController@searchSpecialist');
Route::delete('/E-SEHAT/{id}', 'SehatController@destroy');

Route::get('/E-SEHAT/{id}/fee', 'SehatController@sort');
Route::get('/E-SEHAT/{id}/city', 'SehatController@sortCity');
Route::get('/E-SEHAT/{id}/specilist', 'SehatController@sortSpecility');
Route::get('/E-SEHAT/{id}/disease', 'SehatController@sortDisease');
Route::get('/E-SEHAT/{id}/{speclty}/{city}/fee', 'SehatController@sortFee');
Route::post('/showdoc', 'SehatController@sortByCity');
Route::post('/select', 'SehatController@selectdoc');
Route::get('/E-SEHAT/{id}/viewDocprofile', 'SehatController@MyDocprofile');





/*Route::get('/students', function () {
    return view('students');
});*/
Route::get('/prof/{id?}', 'profile@show');
Route::get('/about', 'profile@about');
Route::get('/contact', 'profile@contact');
Route::resource('students','StudentController');
Route::resource('roles','RoleController');
Route::get('forms/create','FormController@create');
Route::post('/forms','FormController@store');
Route::get('/forms/{id}/edit','FormController@edit');
Route::get('/forms/update/{id}/','FormController@update');




