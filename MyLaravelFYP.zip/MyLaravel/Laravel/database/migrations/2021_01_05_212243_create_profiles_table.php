<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProfilesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('profiles', function (Blueprint $table) {
            $table->biginteger('id');
            $table->string('Image')->nullable();
            $table->text('About');
            $table->text('Qualification');
            $table->text('Services');
            $table->text('Experience');
            $table->string('Experience_Time');
            $table->text('Organization');
            $table->string('Location');
            $table->string('City');
            $table->text('Working_days');
            $table->string('Time');
            $table->string('Duration');
            $table->string('Fees');
            $table->text('VWorking_days');
            $table->string('VTime');
            $table->string('VDuration');
            $table->string('VFees');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('profiles');
    }
}
