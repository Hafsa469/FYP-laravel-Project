<?php $__env->startSection('title','Login Form'); ?>
<?php $__env->startSection('contents'); ?>
<h1>Hafsa</h1>
<div class="container">

<form action="/Laravel/Laravel/public//forms/update/<?php echo e($form->id); ?>/" method="POST">
<?php echo e(csrf_field()); ?>

<div>
<label>Name</label>
<input type="text" name="name" placeholder="Name" value="<?php echo e($form->Name); ?>"/>
</div>
<div>
<label>Password</label>
<input type="password" name="password" placeholder="Password" value="<?php echo e($form->password); ?>"/>
</div>
<div>
<label>Email</label>
<input type="email" name="email" placeholder="Email" value="<?php echo e($form->email); ?>"/>
</div>
<button>Submit</button>
</form>
<?php if(session('message')): ?>
<p class="alert alert-success"><?php echo e(session('message')); ?></p>
<?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/forms/edit.blade.php ENDPATH**/ ?>