<?php $__env->startSection('title','Doctor Registration Form'); ?>
<?php $__env->startSection('contents'); ?>



<div class="d_wrapper">
   <div class="dl_form-wrapper">
    
   <form action="<?php echo e(url('/doctorLog')); ?>" method="POST" enctype="multipart/form-data">
      <?php if(count($errors) > 0): ?>
               <div class = "alert alert-danger" id="cerrors">
                  <ul>
                     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
               </div>
      <?php endif; ?>
      <div class="clinics">
         <h2>You are one step away from creating your profile</h2>
         <ul>
            <li>Enter all information about yourself.</li>
            <li>After Verification, you would be allowed to login as doctor.</li>
            <li>After Login,You have to complete your Profile, then your profile will be live for patients.</li>
         </ul>
      </div>
      <?php if(session()->has('success')): ?>
         <div class="alert alert-success" id="success" >
            <?php echo e(session()->get('success')); ?>

         </div>
      <?php endif; ?> 
      <?php echo e(csrf_field()); ?>

      

      <div class="space"></div>
      <div>
      <label>Name:</label>
      <input type="text" size="15" name="name" pattern="[A-Z][a-z]*{2,}" title="Enter Your Full Name of atleast two words" placeholder="Your Name" class="doc" />

      <label>Email:</label>
      <input type="email" size="15" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" placeholder="Your Email" class="doc" />

      </div>
      <br/>
      <div> 
      <label>Phone #:</label>
      <input type="text" size="15" pattern="[0]{1}[3]{1}[0-9]{9}" 
            title="Phone number with 03 and remaing 9 digit with 0-9" maxlength="11" name="phone" placeholder="eg 0315"  class="doc" />

      <label>City:</label>
      <input type="text" size="15" name="city" pattern="[A-Z][a-z]*" title="Must Capitalize Your First Letter like Lahore" placeholder="Your City" class="doc"/>

      </div>
      <br/>
      <div>
      <label>Designation:</label>
      <input type="text" size="15" name="designation" pattern="[A-Z][a-z]*{1,}" title="Must Capitalize Your First Letter" placeholder="Designation" class="doc" />

      <label>Speciality:</label>
      <input type="text" size="15" name="speciality" pattern="[A-Z][a-z]*{1,}" title="Must Capitalize Your First Letter like Cardiologist" placeholder="Speciality" class="doc" />
      </div>
      </br/>

      <div>
      <label>PMDC #:</label>
      <input type="text" size="15" placeholder="PMDC" name="pmdc" class="doc"  id="pmdc"/>

      <label>Choose Password:</label>
      <input type="password" size="10" name="password" pattern=".{6,}" title="Six or more characters" maxlength="6" placeholder="Password" class="doc" id="pass"/>
      </div><br>
      <div>
      <label>Upload CV:</label><br/>
      <input type="file" name="file"  id="cv"/>
      </div>
      <div>
      <label>Message:</label><br/>
      <textarea id="mess" rows=5 cols=120 name="message" placeholder="Type your Message here "></textarea>
      </div>
      <br/>
      <button class="btn btn-outline-primary"  id="d_btnn" name="txtbutton" ><a >Submit</a></button>


   </form>


   </div>
</div>
<?php $__env->stopSection(); ?>











<?php echo $__env->make('layout.sehat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyLaravel\Laravel\resources\views/E-SEHAT/doctorLogin.blade.php ENDPATH**/ ?>