<?php $__env->startSection('title','Health & Nutrition Form'); ?>
<?php $__env->startSection('contents'); ?>


<div class="wrapper">
       <div class="nform-wrapper">
       <?php echo e(csrf_field()); ?>

<table id="form">
<tbody>
<thead>
    
    <th>Diet Plans</th>
   
</thead>
<?php $i=1 ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(($data) != ""): ?>
        <tr>
            <?php if(($key) == 0): ?>
            <th>Disease:<span id="data2"><?php echo e($data); ?></span></th>
            
            <?php elseif(($key) != 0): ?>
            <td><span id="no"><?php echo $i.")"; $i++; ?></span><span id="data"><?php echo e($data); ?><?php echo "." ?></span></td>
            <?php endif; ?>
        </tr>
        
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tbody>
</table>

<br><br>
<div>
<label id="sat">Are You Satisfied with this Diet Plan?</label><br/>
<label id="sat">If No, You can Consult a Dietitian/Nutritionist!</label><br/>
</div>
<br/>
<button class="btn btn-secondary btn-lg"  id="dieti" name="txtbutton" ><a href='/MyLaravel/Laravel/public/E-SEHAT/searchSpecialist'>Consult Nutritionist</a></button>

<br/>

</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.sehat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyLaravel\Laravel\resources\views/E-SEHAT/show.blade.php ENDPATH**/ ?>