<?php $__env->startSection('title','Login Form'); ?>
<?php $__env->startSection('contents'); ?>
<h1>My Cars</h1>
<form method='post' action="<?php echo e(url('/create')); ?>">
<?php echo csrf_field(); ?>
<div>
<label>Enter color:</label>
<input type='text' name='color'/>
</div>
<div>
<label>Enter Price:</label>
<input type='number' name='price'/>
<div>
<div>
<label>Enter Company:</label>
<input type='text' name='company'/>
</div>
<input type='submit' name='submit'/>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/cars/create.blade.php ENDPATH**/ ?>