<?php $__env->startSection('title','Login Form'); ?>
<?php $__env->startSection('contents'); ?>




<div class="wrap">
       <div class="ddform-wrapper">
    
<form action="" method="POST">
<?php echo e(csrf_field()); ?>

    <div>
    <label id="click">Complete Your Profile First:</label><br/>
    </div>
    <br/>
    <button class="btn btn-outline-primary"  id="ebtn" name="txtbutton" ><a href="<?php echo e(url('/E-SEHAT/doctorProfile')); ?>">Profile Settings</a></button>
    <br/>

    <br/>

</form>



</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.doctor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyLaravel\Laravel\resources\views/E-SEHAT/askprof.blade.php ENDPATH**/ ?>