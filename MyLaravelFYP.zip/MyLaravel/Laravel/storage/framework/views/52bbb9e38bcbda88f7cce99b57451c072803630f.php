<?php $__env->startSection('title','Doctor Form'); ?>
<?php $__env->startSection('contents'); ?>

<?php echo e(csrf_field()); ?>



<div class="d_wrapper">
    <div class="md_form-wrapper">
          
                <br><br>
                
              <h1 class="hdng" style="text-align:center"><u> Your Appointments</u> </h1><br>
              <?php if(!empty($success)): ?>
                <div class="alert alert-success" id="cerrors"> 
                <?php echo e($success); ?>

                </div>
              <?php endif; ?>
              <?php $__currentLoopData = $doctor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <form method='post' action="/MyLaravel/Laravel/public/E-SEHAT/<?php echo e($doctor['booking_id']); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
              <div class="Uclinic">
              <br>
              <div>
                     <p><img src="/MyLaravel/Laravel/storage/uploads<?php echo e($doctor['Image']); ?>" id="output" width="200" /></p>
              </div>
              <div class="info">
                     <span class="ffi"><u><?php echo e($doctor["name"]); ?></u></span><br>
                     <span class="red2"><?php echo e($doctor["designation"]); ?><span class="red2">,<span><span class="red2"><?php echo e($doctor["speciality"]); ?></span></span><br>
                     <span class="ffi"><?php echo e($doctor['Organization']); ?><span class="ffi">,<span><span class="ffi"><?php echo e($doctor["Location"]); ?></span></span><br>
                     <span class="ffi"><?php echo e($doctor['City']); ?><span class="ffi">,<span><span class="ffi"><?php echo e($doctor["Experience_Time"]); ?></span><span class="ffi">Experience <span></span>
              </div>
              <button class="btn btn-outline-primary" style="position:relative; bottom:190px; right:120px;" id="e_btnn" name="txtbutton" ><a href="/MyLaravel/Laravel/public/E-SEHAT/<?php echo e($doctor['id']); ?>/viewDocprofile">View Profile</a></button>
              <div class="btn btn-danger" id="phonei" style="position:relative; bottom:230px; left:515px;" onclick="call();"><i class="fa fa-phone" > Call</i></div>
              <div  style="position:relative; bottom:150px; left:20px;">
                     <span class="ff">Patient Name:  <span class="red2"><?php echo e($doctor["bname"]); ?></span></span><br>
                     <span class="ff">Patient Phone No:  <span class="red2"><?php echo e($doctor["bphone"]); ?></span></span><br>
                     <span class="ff">Appointment Date:  <span class="red2"><?php echo e($doctor["date"]); ?></span></span><br>
                     <span class="ff">Appointment Type:  <span class="red2"><?php echo e($doctor["type"]); ?></span></span><br>
                     <span class="ff">Appointment Day:  <span class="red2"><?php echo e($doctor["day"]); ?></span></span><br>
                     <span class="ff">Appointment Time:  <span class="red2"><?php echo e($doctor["time"]); ?></span></span>
                     
              </div>
              <button class="btn btn-outline-danger"  id="e_btnn" name="txtbutton"  style="position:relative; bottom:120px"><a >Remove</a></button><br>
              </div>
             </form>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
              
    </div>
</div>       


<script>
function call()
{
   //alert(" Call E-SEHAT Helpline (8:00 AM - 12:00 PM)\n Call 03245334289\n OR\n Call 03127179923 ");
   swal("Call E-SEHAT Helpline (8:00 AM - 12:00 PM)", "Call 03245334289, Call 03127179923");
}
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.sehat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyLaravel\Laravel\resources\views/E-SEHAT/userProfile.blade.php ENDPATH**/ ?>