<?php $__env->startSection('title','Try Form'); ?>
<?php $__env->startSection('contents'); ?>

<?php echo e(csrf_field()); ?>



<div class="d_wrapper">
       <div class="d_form-wrapper">
    
<form action="<?php echo e(url('/results')); ?>" method="POST">
<?php echo e(csrf_field()); ?>

<table>
<tbody>
<thead>
    
    <th id="head">Search Related To Your Symptoms Experienced</th>
    <th><p id="headr">Select among the 4 DropDown Options</p></th>
    
   
</thead>
<?php $i=0 ?>
    
    
        <tr>
            <td>
                <span id="no"><?php echo $i.")"; $i++; ?></span><span id="data"><?php echo e($result_ar); ?></span>


            </td>
            <td>
                <select name="postive" id="doc2" >
                    <option value=<?php echo e($result_ar); ?>>Agreed</option>
                    <option value=<?php echo e($result_ar); ?>>Strongly Agreed</option>
                    <option value=<?php echo e($result_ar); ?>>Weekly Agreed</option>
                    <option value="">Disagreed</option>
                </select>
            </td>
        </tr> 
       
    
    <tbody>
</table>
<br/><br/>
<button class="btn btn-outline-primary"  id="d_btnn" name="txtbutton" ><a >Submit</a></button>
</form>


</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.sehat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyLaravel\Laravel\resources\views/E-SEHAT/try.blade.php ENDPATH**/ ?>