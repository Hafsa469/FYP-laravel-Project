<?php $__env->startSection('title','Login Form'); ?>
<?php $__env->startSection('contents'); ?>

<?php echo e(csrf_field()); ?>



<div class="d_wrapper">
       <div class="d_form-wrapper">
    
<form action="<?php echo e(url('/results')); ?>" method="POST">
<?php echo e(csrf_field()); ?>

<table>
<tbody>
<thead>
    <th id="head">Outcomes</p></th>
</thead>
<?php $i=1 ?>
    <?php $__currentLoopData = $result_ar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $result_ar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(($key) == 0): ?>
        <tr>
            <td>
                <br>
                <div class="alert alert-warning">
                    <strong>Warning!</strong> <?php echo e($result_ar); ?>

                </div>
               <br/>
            </td>
        </tr> 
    <?php endif; ?>
    <?php if(($key) == 1): ?>
        <tr>
            <td>
               <span id="head1">Predicted Disease:</span><span class="alert alert-danger" id="data1"><?php echo e($result_ar); ?></span>
            </td>
        </tr> 
    <?php endif; ?>
    <?php if(($key) == 2): ?>
        <?php if($result_ar != " "): ?>
        <tr>
            <br/>
            <td>
                <span class="alert alert-danger" id="data1"><strong>OR May Have:</strong><?php echo e($result_ar); ?></span>
            </td>
        </tr> 
        <?php endif; ?>
    <?php endif; ?>
    <?php if(($key) == 3): ?>
        <tr>
            <td>
                <br/>
                <p id="head1">Disease Description</p>
                <span  id="data"><?php echo e($result_ar); ?></span>

            </td>
        </tr> 
    <?php endif; ?>  
    <?php if(($key) == 4): ?>
        <?php if($result_ar != " "): ?>
        <tr>
            <td>
                
                <span id="data"><?php echo e($result_ar); ?></span>

            </td>
        </tr> 
        <?php endif; ?> 
    <?php endif; ?>  
    <?php if(($key) == 5): ?>
        <tr>
            <td>
                <br/>
                <p id="head1"><?php echo e($result_ar); ?></p>

            </td>
        </tr> 
    <?php endif; ?>  
    <?php if(($key) > 5): ?> 
        <tr>
            <td>
                <span id="no"><?php echo $i.")"; $i++; ?></span><span id="data"><?php echo e($result_ar); ?></span>

            </td>
        </tr>
    <?php endif; ?>  
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tbody>
</table>

</form>


</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.sehat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/E-SEHAT/output.blade.php ENDPATH**/ ?>