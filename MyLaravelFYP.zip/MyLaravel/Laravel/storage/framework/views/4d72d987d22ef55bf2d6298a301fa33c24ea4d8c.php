<?php $__env->startSection('title','Doctor Form'); ?>
<?php $__env->startSection('contents'); ?>

<?php echo e(csrf_field()); ?>



<div class="d_wrapper">
    <div class="mdp_form-wrapper">
                
                <br>
                
              <form>
              <?php echo e(csrf_field()); ?>

              <p><img src="/MyLaravel/Laravel/public/images/doctor.png" id="doutput" width="200" /></p>
              <!-- Example single danger button -->
              <div class="dropdown">
              <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Dropdown Example
              <span class="caret"></span></button>
              <ul class="dropdown-menu">
              <li><a href="#">HTML</a></li>
              <li><a href="#">CSS</a></li>
              <li><a href="#">JavaScript</a></li>
              </ul>
              </div>
              <?php $__currentLoopData = $doctor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="clinic">
              <br><br>
              <div>
                     <p><img src="/MyLaravel/Laravel/storage/uploads<?php echo e($doctor['Image']); ?>" id="output" width="200" /></p>
              </div>
              <div style=" position:relative; left:250px; bottom:200px;">
                     <span class="red1"><u><?php echo e($doctor["name"]); ?></u></span><br>
                     <span class="red2"><?php echo e($doctor["designation"]); ?><span class="red2">,<span><span class="red2"><?php echo e($doctor["speciality"]); ?></span></span><br>
                     <span class="red1"><?php echo e($doctor["Organization"]); ?><span class="red1">,<span><span class="red1"><?php echo e($doctor["Location"]); ?></span></span><br>
                     <span class="red1"><?php echo e($doctor["City"]); ?><span class="red1">, Experience<span><span class="red1"><?php echo e($doctor["Experience_Time"]); ?></span></span>  
              </div>
              <div style=" position:relative; left:390px; bottom:350px;">
              <button class="btn btn-outline-primary"  id="e_btnn" name="txtbutton" ><a href='/MyLaravel/Laravel/public/E-SEHAT/<?php echo e($key); ?>/clinic'>Book In-Clinic Appointment</a></button>
              <button class="btn btn-outline-primary"  id="e_btnn" name="txtbutton" ><a href='/MyLaravel/Laravel/public/E-SEHAT/<?php echo e($key); ?>/video'>Book Video Consultation</a></button>
              <button class="btn btn-outline-primary"  id="e_btnn" name="txtbutton" ><a href='/MyLaravel/Laravel/public/E-SEHAT/<?php echo e($key); ?>/viewprofile'>View Profile</a></button>
              </div>
              <p class="fff" style=" position:relative; left:2px; bottom:240px; right:25px;"><span class="red2" style="font-size:20px;">Message: </span><?php echo e($doctor["message"]); ?></p>
             
   
              </div>
             
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </form>
              

            

       


    </div>
</div>       




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.sehat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyLaravel\Laravel\resources\views/E-SEHAT/doctors.blade.php ENDPATH**/ ?>