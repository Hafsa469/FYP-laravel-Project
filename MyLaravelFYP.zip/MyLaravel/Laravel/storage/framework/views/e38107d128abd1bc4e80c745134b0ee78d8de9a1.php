<?php $__env->startSection('title','Doctor Profile Form'); ?>
<?php $__env->startSection('contents'); ?>

<?php echo e(csrf_field()); ?>



<div class="d_wrapper">
    <div class="mdp_form-wrapper">
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success" id="success" >
                <?php echo e(session()->get('success')); ?>

            </div>
        <?php endif; ?> 
                <h1>Complete Your Profile First</h1>
                <br>
              <form action="<?php echo e(url('/updateProfile')); ?>" method="POST" enctype="multipart/form-data">
            
                     <?php if(count($errors) > 0): ?>
                            <div class = "alert alert-danger" id="cerrors">
                            <ul>
                                   <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <li><?php echo e($error); ?></li>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            </div>
                     <?php endif; ?>

                   

              <?php echo e(csrf_field()); ?>

             
              <div>
                     <p><input type="file"  accept="image/*" name="image" id="file" value="<?php echo e($doctor['Image']); ?>" onchange="loadFile(event)" style="display: none;"></p>
                     <p><label for="file" class="ff" style="cursor: pointer;">Upload Image:</label><img id="output" width="200" src="/MyLaravel/Laravel/storage/uploads<?php echo e($doctor['Image']); ?>" /></p>
                     
              </div>
       
              <div>
                <label  class="ff">Personel Information:</label><br/>
                <textarea id="mess" rows=5 cols=120 name="about" placeholder="Type about yourself here "><?php echo e($doctor['About']); ?></textarea>
              </div>
              <div>
                <label  class="ff">Enter Your Qualification:</label><br/>
                <textarea id="mess" rows=5 cols=120 name="qualification" placeholder="Type your Qualification here " ><?php echo e($doctor['Qualification']); ?></textarea>
              </div>
              <div>
                <label  class="ff">Enter Your Services:</label><br/>
                <textarea id="mess" rows=5 cols=120 name="services" placeholder="Type your Services here " ><?php echo e($doctor['Services']); ?></textarea>
              </div>
              <div>
                <label  class="ff">Enter Your Working Experience:</label><br/>
                <textarea id="mess" rows=5 cols=120 name="experience" placeholder="Type your Experience here " ><?php echo e($doctor['Experience']); ?></textarea>
              </div>

              <div>
                <label  class="ff">For How many time you have?</label><br/>
                <input type="number" size="10" name="yearNo" class="doc" value= "<?php echo e($doctor['FExperience_Time']); ?>" />
                <select name="years" class="doc" >
                    <option><?php echo e($doctor['Experience_Time']); ?></option>
                     <option>Years</option>
                     <option>Months</option>
                </select> 
              </div>

              <div class="clinic">
              <br>
                     <h2>Organization Address</h2>
                     <div>
                            <label  class="ff">Name of your Working Organization:</label>
                            <input type="text" size="15" name="organization" class="doc" value="<?php echo e($doctor['Organization']); ?>"/><br/><br>
                            <label  class="ff">Location:</label>
                            <input type="text" size="15" name="location" class="doc" value="<?php echo e($doctor['Location']); ?>" />
                            <label  class="ff">City:</label>
                            <input type="text" size="15" name="city" class="doc" value="<?php echo e($doctor['City']); ?>"/>
                     </div>
              <br>
              </div>
              
              <div class="clinic">
              <br>
                     <h2>In-Clinic Appointement</h2>
                     <div>
                            <br>
                           
                            <span  class="red1">Your Selected Days:</span><span class="red" name="working"><?php echo e($doctor['Working_days']); ?></span><br>
                            <label class="ff">Update Your Available Days:</label><br>
                            <span class="check">Monday</span>
                            <input type="checkbox" name="days[]" value="Monday"/> <br>
                            <span class="check">Tuesday</span>
                            <input type="checkbox"  name="days[]" value="Tuesday"/> <br>
                            <span class="check1">Wednesday</span>
                            <input type="checkbox"  name="days[]" value="Wednesday"/><br> 
                            <span class="check2">Thursday</span>
                            <input type="checkbox"  name="days[]" value="Thursday"/> <br>
                            <span class="check3">Friday</span>
                            <input type="checkbox" name="days[]" value="Friday"/> <br>
                            <span class="check4">Saturday</span>
                            <input type="checkbox" name="days[]" value="Saturday"/><br> 
                            <span class="check5">Sunday</span>
                            <input type="checkbox"  name="days[]" value="Sunday"/> <br><br>

                            <label class="ff">Select Your Available Timings:</label><br>
                            <!--<span class="ff">From:</span><input type="text" size="10" name="from" class="doc" value="<?php echo e($doctor['FTime']); ?>" />
                            <span class="ff">To:</span><input type="text" size="10" name="to" class="doc" value="<?php echo e($doctor['Time']); ?>"/><br>-->
                            <span class="ff">From:</span><label class="red2" id="startTime" name="startTime"><?php echo e($doctor['FTime']); ?></label><input type="hidden" name="from" id="mystart" value="<?php echo e($doctor['FTime']); ?>"/>
                            <span class="ff">Change Time:</span><input type="time" size="10" id="Cfrom" name="Cfrom" class="doc" value="<?php echo e($doctor['FTime']); ?>"/><label class="red2" style="cursor: pointer;" onclick="uploadS()"><u>Upload Time</u></label><br>
                            <span class="ff">To:</span><label class="red2" id="endTime" name="endTime"><?php echo e($doctor['Time']); ?></label><input type="hidden" name="to" id="myend" value="<?php echo e($doctor['Time']); ?>"/>
                            <span class="ff">Change Time:</span><input type="time" size="10" id="Cto" name="Cto" class="doc" value="<?php echo e($doctor['Time']); ?>"/><label class="red2" style="cursor: pointer;" onclick="uploadE();"><u>Upload Time</u></label><br>
                            <br>
                            <label class="ff">Select Your Appointement Duration(min):</label>
                            <select  name="duration"  id="disease" class="doc" >
                                <option><?php echo e($doctor['Duration']); ?></option><option>10</option><option>15</option><option>20</option><option>25</option><option>30</option>
                            </select>
                               
                     </div>
 
                     <br>
                     <div>
                            <label class="ff">Enter Your Fees:</label>
                            <input type="text" size="10" name="fees" class="doc" value="<?php echo e($doctor['Fees']); ?>"/>
                            
                     </div>

              <br><br>
              </div>
              <div class="video">
              <br>
                     <h2>Video Consultation</h2>
                     <div>
                            <br>
                            
                            <span  class="red1">Your Selected Days:</span><span class="red" name="vworking"><?php echo e($doctor['VWorking_days']); ?></span><br>
                            <label class="ff">Update Your Available Days:</label><br>
                            <span class="check">Monday</span>
                            <input type="checkbox" name="Vdays[]" value="Monday"/><br>
                            <span class="check">Tuesday</span>
                            <input type="checkbox"  name="Vdays[]" value="Tuesday"/><br>
                            <span class="check1">Wednesday</span>
                            <input type="checkbox"  name="Vdays[]" value="Wednesday"/><br> 
                            <span class="check2">Thursday</span>
                            <input type="checkbox"  name="Vdays[]" value="Thursday"/><br>
                            <span class="check3">Friday</span>
                            <input type="checkbox" name="Vdays[]" value="Friday"/><br>
                            <span class="check4">Saturday</span>
                            <input type="checkbox" name="Vdays[]" value="Saturday"/><br> 
                            <span class="check5">Sunday</span>
                            <input type="checkbox"  name="Vdays[]" value="Sunday"/><br><br>

                            <label class="ff">Select Your Available Timings:</label><br>
                            <!--<span class="ff">From:</span><input type="text" size="10" name="Vfrom" class="doc" value="<?php echo e($doctor['FVTime']); ?>"/>
                            <span class="ff">To:</span><input type="text" size="10" name="Vto" class="doc" value="<?php echo e($doctor['VTime']); ?>"/><br>-->

                            <span class="ff">From:</span><label class="red2" id="VstartTime" name="VstartTime"><?php echo e($doctor['FVTime']); ?></label><input type="hidden" name="Video_from" id="Vmystart" value="<?php echo e($doctor['FVTime']); ?>"/>
                            <span class="ff">Change Time:</span><input type="time" size="10" id="Vfrom" name="Cfrom" class="doc" value="<?php echo e($doctor['FVTime']); ?>"/><label class="red2" style="cursor: pointer;" onclick="uploadVS()"><u>Upload Time</u></label><br>
                            <span class="ff">To:</span><label class="red2" id="VendTime" name="VendTime"><?php echo e($doctor['VTime']); ?></label><input type="hidden" name="Video_to" id="Vmyend" value="<?php echo e($doctor['VTime']); ?>"/>
                            <span class="ff">Change Time:</span><input type="time" size="10" id="Vto" class="doc" value="<?php echo e($doctor['VTime']); ?>"/><label class="red2" style="cursor: pointer;" onclick="uploadVE();"><u>Upload Time</u></label><br>
                            <br>
                            <label class="ff">Select Your Appointement Duration(min):</label>
                            <select  name="Vduration"  id="disease" class="doc" value="<?php echo e($doctor['VDuration']); ?>">
                                   <option>10</option><option>15</option><option>20</option><option>25</option><option>30</option>
                            </select>                             
                     </div>
                     <br>
                     <div>
                            <br>
                            <label class="ff">Enter Your Fees:</label>
                            <input type="text" size="10" name="Vfees" class="doc" value="<?php echo e($doctor['VFees']); ?>" />
                            
                     </div>

              <br>
              </div>
            
              <br/>
              <br/>
              <button class="btn btn-outline-primary"  id="d_btnn" name="txtbutton" ><a >Update</a></button>
              </form>

    </div>
</div>       

<script>
var loadFile = function(event) {
	var image = document.getElementById('output');
	image.src = URL.createObjectURL(event.target.files[0]);
};
function uploadS(){
       var n=document.getElementById('Cfrom').value;
       var b=document.getElementById('startTime');
       var n1 =n.split(':');
       var time = hours_am_pm(n1[0]+n1[1]);
       b.innerHTML =time;
       n.value=time;
       document.getElementById('mystart').value=time;
       //document.getElementById('d').value=time;
       //b.innerHTML=a;
   
}
function uploadE(){
       var n=document.getElementById('Cto').value;
       var b=document.getElementById('endTime');
       var n1 =n.split(':');
       var time = hours_am_pm(n1[0]+n1[1]);
       b.innerHTML =time;
       n.value=time;
       document.getElementById('myend').value=time;
       //b.innerHTML=a;
   
}
function uploadVS(){
       var n=document.getElementById('Vfrom').value;
       var b=document.getElementById('VstartTime');
       var n1 =n.split(':');
       var time = hours_am_pm(n1[0]+n1[1]);
       b.innerHTML =time;
       n.value=time;
       document.getElementById('Vmystart').value=time;
       //b.innerHTML=a;
   
}
function uploadVE(){
       var n=document.getElementById('Vto').value;
       var b=document.getElementById('VendTime');
       var n1 =n.split(':');
       var time = hours_am_pm(n1[0]+n1[1]);
       b.innerHTML =time;
       n.value=time;
       document.getElementById('Vmyend').value=time;
       //b.innerHTML=a;
   
}
  function hours_am_pm(time) {
        var hours = time[0] + time[1];
        var min = time[2] + time[3];
        if (hours < 12) {
            if(hours == "00")
            {
                   hours="12";
            }
            return hours + ':' + min + ' am';
        }
        else {
            hours=hours - 12;
            hours=(hours < 10) ? '0'+hours:hours;
            if(hours == "00")
            {
                   hours="12";
            }
            return hours+ ':' + min + ' pm';
        }
}
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.doctor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyLaravel\Laravel\resources\views/E-SEHAT/editprofile.blade.php ENDPATH**/ ?>