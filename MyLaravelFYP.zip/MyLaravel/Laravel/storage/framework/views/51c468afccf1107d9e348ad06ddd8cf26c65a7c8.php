<?php $__env->startSection('title','Symptoms Form'); ?>
<?php $__env->startSection('contents'); ?>

<?php echo e(csrf_field()); ?>



<div class="d_wrapper">
       <div class="d_form-wrapper">
    
<form >
<?php echo e(csrf_field()); ?>

<table>
<tbody>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $result_ar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(($key) == 0): ?>
            <tr>
                <td>
                    <br>
                    <div class="alert alert-danger">
                        <strong>Symptom:</strong> <?php echo e($result_ar); ?>

                    </div>
                
                </td>
            </tr> 
        <?php endif; ?>
        <?php if(($key) == 1): ?>
            <tr>
                <td>
                    <br>
                    <div class="alert alert-warning">
                        <strong>Symptom Meaning:</strong> <?php echo e($result_ar); ?>

                    </div>
                
                </td>
            </tr> 
        <?php endif; ?>
        <?php if(($key) == 2): ?>
            <tr>
                <td>
                <div class="alert alert-info">
                        <strong>Symptom Description:</strong> <?php echo e($result_ar); ?>

                    </div>
                </td>
            </tr> 
        <?php endif; ?>
    
       
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tbody>
</table>
<br/><br/>

</form>

<button class="btn btn-outline-primary"  id="e_btn" name="txtbutton" onclick="back();" ><a >Back</a></button>
</div>
</div>
<script>
function back()
{
    history.go(-1);
}

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.sehat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyLaravel\Laravel\resources\views/E-SEHAT/symptomDetails.blade.php ENDPATH**/ ?>