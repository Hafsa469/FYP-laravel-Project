<?php $__env->startSection('title','Doctor Form'); ?>
<?php $__env->startSection('contents'); ?>

<?php echo e(csrf_field()); ?>



<div class="d_wrapper">
    <div class="mdp_form-wrapper">
                
                <br><br>
                
              <form>
              <?php echo e(csrf_field()); ?>

              <h1 style="text-align:center;"><u>Your Reviews</u></h1>
              <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $reviews): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="clinics">
                <br><br>
                <div>
                    <label  class="ff">Name:</label>
                    <span class="fff"><?php echo e($reviews['name']); ?></span><br>
                </div>
                <div>
                    <label  class="red2">Review:</label><br/>
                    <textarea id="mess" rows=5 cols=120 name="experience" placeholder="Type your Experience here " readonly style="margin-left:10px;"><?php echo e($reviews['reviews']); ?></textarea>
                </div>
              </div>
             
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </form>

    </div>
</div>       




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.doctor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyLaravel\Laravel\resources\views/E-SEHAT/docReviews.blade.php ENDPATH**/ ?>