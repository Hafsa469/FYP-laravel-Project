<html>
<head>
<head>
<body>
<?php  print_r($users)?>
</body>

</html><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/prof.blade.php ENDPATH**/ ?>