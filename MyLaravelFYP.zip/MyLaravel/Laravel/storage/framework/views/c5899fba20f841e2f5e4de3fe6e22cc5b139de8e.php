<?php $__env->startSection('title','Health & Nutrition Form'); ?>
<?php $__env->startSection('contents'); ?>

<?php if(count($errors) > 0): ?>
         <div class = "alert alert-danger" id="errors">
            <ul>
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
         </div>
<?php endif; ?>

<div class="wrapper">
       <div class="ddform-wrapper">
    
<form action="<?php echo e(url('/nutrition')); ?>" method="POST"  >
<?php echo e(csrf_field()); ?>

<div>
<label>Enter Disease:</label><br/>
<select id="disease" name="disease">
    <option></option>
    <option>Drug Reaction</option>
    <option>Fungal infection</option>
    <option>Malaria</option>
    <option>Allergy</option>
    <option>Hypothyroidism</option>
    <option>Psoriasis</option>
    <option>Chronic cholestasis</option>
    <option>GERD</option>
    <option>Hepatitis A</option>
    <option>Hepatitis B</option>
    <option>Hepatitis C</option>
    <option>Hepatitis D</option>
    <option>Hepatitis E</option>
    <option>Osteoarthristis</option>
    <option>(vertigo) Paroymsal  Positional Vertigo</option>
    <option>Hypoglycemia</option>
    <option>Impetigo</option>
    <option>Diabetes</option>
    <option>Acne</option>
    <option>Hypertension</option>
    <option>Peptic ulcer disease</option>
    <option>Dimorphic hemorrhoids(piles)</option>
    <option>Common Cold</option>
    <option>Chicken pox</option>
    <option>Cervical spondylosis</option>
    <option>Hyperthyroidism</option>
    <option>Urinary tract infection</option>
    <option>Varicose veins</option>
    <option>AIDS</option>
    <option>Paralysis (brain hemorrhage</option>
    <option>Typhoid</option>
    <option>Migraine</option>
    <option>Bronchial Asthma</option>
    <option>Alcoholic hepatitis</option>
    <option>Jaundice</option>
    <option>Dengue</option>
    <option>Heart attack</option>
    <option>Pneumonia</option>
    <option>Arthritis</option>
    <option>Gastroenteritis</option>
    <option>Tuberculosis</option>
    <option>COVID-19</option>
</select>
</div>
<br/>

<button class="btn btn-outline-primary"  id="hbtnn" name="txtbutton" ><a >Submit</a></button>



</form>



</div>
</div>
<?php $__env->stopSection(); ?>











<?php echo $__env->make('layout.sehat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/E-SEHAT/nutrition.blade.php ENDPATH**/ ?>