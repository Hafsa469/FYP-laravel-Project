<?php $__env->startSection('title','Login Form'); ?>
<?php $__env->startSection('contents'); ?>




<div class="wrapper">
       <div class="ddform-wrapper">
    
<form action="" method="POST">
<?php echo e(csrf_field()); ?>

<div>
<label id="click">For Disease Diagonosis You must have to Login First:</label><br/>
</div>
<br/>
<button class="btn btn-outline-primary"  id="hbtnn" name="txtbutton" ><a href="<?php echo e(url('/E-SEHAT/login')); ?>">Login</a></button>
<br/>
<div>
<label id="click">If You dont't have any account..Must Create it First:</label><br/>
</div>
<br/>
<button class="btn btn-outline-primary"  id="hbtnn" name="txtbutton" ><a href="<?php echo e(url('/E-SEHAT/UserRegister')); ?>">Create Account</a></button>
</form>



</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.sehat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/E-SEHAT/askLogin.blade.php ENDPATH**/ ?>