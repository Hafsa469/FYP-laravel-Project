<?php $__env->startSection('title','Login Form'); ?>
<?php $__env->startSection('contents'); ?>



<?php echo e(csrf_field()); ?>



<div class="d_wrapper">
       <div class="d_form-wrapper">
    
<form action="<?php echo e(url('/diagonose1')); ?>" method="POST">
<?php if(count($errors) > 0): ?>
         <div class = "alert alert-danger" id="cerrors">
            <ul>
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
         </div>
<?php endif; ?>
<?php echo e(csrf_field()); ?>

<div class="space"></div>
<div>
<label>Patient Name:</label>
<input type="text" size="10" name="name" placeholder="Your Name" class="doc" />

<label>Sex:</label>
<select name="gender" class="doc1">
<option>Male</option>
<option>Female</option>
</select>

</div>
<br/>
<div> 
<label>Patient Age:</label>
<input type="number" size="10" min=1 max=150 name="age"  class="doc" />
</div>
<br/>

<div> 
<label>Enter any Symptom you are experencing:</label>
<input type="text" pattern="[a-z]*" name="symptom" placeholder="symptom" class="doc" />
</div>
<br/>
<button class="btn btn-outline-primary"  id="ebtn" name="txtbutton" ><a >Submit</a></button>


</form>


</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.sehat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyLaravel\Laravel\resources\views/E-SEHAT/diagonose1.blade.php ENDPATH**/ ?>