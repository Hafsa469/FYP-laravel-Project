<?php $__env->startSection('title','Login Form'); ?>
<?php $__env->startSection('contents'); ?>
<h1>My Cars</h1>
<form method='post' action="/Laravel/Laravel/public/cars/<?php echo e($car->id); ?>">
<?php echo csrf_field(); ?>
<?php echo method_field('put'); ?>
<div>
<label>Enter color:</label>
<input type='text' name='color' value="<?php echo e($car->color); ?>"/>
</div>
<div>
<label>Enter Price:</label>
<input type='number' name='price'  value="<?php echo e($car->price); ?>"/>
<div>
<div>
<label>Enter Company:</label>
<input type='text' name='company'  value="<?php echo e($car->company); ?>"/>
</div>
<button name='submit'>Update</button>
</form>
<form method='post' action="/Laravel/Laravel/public/cars/<?php echo e($car->id); ?>">
<?php echo csrf_field(); ?>
<?php echo method_field('DELETE'); ?>
<button name='submit'>Delete</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/cars/edit.blade.php ENDPATH**/ ?>