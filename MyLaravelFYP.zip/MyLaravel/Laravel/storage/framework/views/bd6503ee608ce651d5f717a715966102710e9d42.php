<?php $__env->startSection('title','Main Menu'); ?>
<?php $__env->startSection('contents'); ?>



<?php echo e(csrf_field()); ?>



<img src="/Laravel/Laravel/public/images/image6.jpg" class="img" />
<p id="para">We Care</p>
<p id="para1">For Your Health</p>
<p id="para2">Our Team of Doctors are specialized in Various Disciplines to make <br>sure you get the Best Traetment</p>


<button class="btn btn-outline-primary"  id="sbtn" name="txtbutton" ><a href="<?php echo e(url('/E-SEHAT/UserRegister')); ?>" >Signup Now</a></button>
<button class="btn btn-outline-primary"  id="lbtn" name="txtbutton" ><a href="<?php echo e(url('/E-SEHAT/login')); ?>">Login</a></button>
<?php $__env->stopSection(); ?>











<?php echo $__env->make('layout.sehat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/E-SEHAT/menu.blade.php ENDPATH**/ ?>