<?php $__env->startSection('title','Car Forms'); ?>
<?php $__env->startSection('contents'); ?>
<h1>My Cars</h1>

<?php echo csrf_field(); ?>
<div>
<table>
<tbody>
<thead>
    <th>Color</th>
    <th>Price</th>
    <th>Company</th>
    <thead>
    <?php $__currentLoopData = $car; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td><?php echo e($car->color); ?></td>
        <td><?php echo e($car->price); ?></td>
        <td><?php echo e($car->company); ?></td>
       
        <td><button><a href='/Laravel/Laravel/public/cars/<?php echo e($car->id); ?>/edit'>Edit</a></button></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/cars/show.blade.php ENDPATH**/ ?>