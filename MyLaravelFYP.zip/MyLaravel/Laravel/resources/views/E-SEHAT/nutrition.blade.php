@extends('layout.sehat')
@section('title','Health & Nutrition Form')
@section('contents')



<div class="wrap">
       <div class="ddform-wrapper">
    
<form action="{{url('/nutrition')}}" method="POST"  >
@if (count($errors) > 0)
         <div class = "alert alert-danger" id="cerrors">
            <ul>
               @foreach ($errors->all() as $error)
                  <li>{{ $error }}</li>
               @endforeach
            </ul>
         </div>
@endif
{{csrf_field()}}
<div>
<label>Enter Disease:</label><br/>
<select id="disease" name="disease">
    <option></option>
    <option>Drug Reaction</option>
    <option>Fungal infection</option>
    <option>Malaria</option>
    <option>Allergy</option>
    <option>Hypothyroidism</option>
    <option>Psoriasis</option>
    <option>Chronic cholestasis</option>
    <option>GERD</option>
    <option>Hepatitis A</option>
    <option>Hepatitis B</option>
    <option>Hepatitis C</option>
    <option>Hepatitis D</option>
    <option>Hepatitis E</option>
    <option>Osteoarthristis</option>
    <option>(vertigo) Paroymsal  Positional Vertigo</option>
    <option>Hypoglycemia</option>
    <option>Impetigo</option>
    <option>Diabetes</option>
    <option>Acne</option>
    <option>Hypertension</option>
    <option>Peptic ulcer disease</option>
    <option>Dimorphic hemorrhoids(piles)</option>
    <option>Common Cold</option>
    <option>Chicken pox</option>
    <option>Cervical spondylosis</option>
    <option>Hyperthyroidism</option>
    <option>Urinary tract infection</option>
    <option>Varicose veins</option>
    <option>AIDS</option>
    <option>Paralysis (brain hemorrhage</option>
    <option>Typhoid</option>
    <option>Migraine</option>
    <option>Bronchial Asthma</option>
    <option>Alcoholic hepatitis</option>
    <option>Jaundice</option>
    <option>Dengue</option>
    <option>Heart attack</option>
    <option>Pneumonia</option>
    <option>Arthritis</option>
    <option>Gastroenteritis</option>
    <option>Tuberculosis</option>
    <option>COVID-19</option>
</select>
</div>
<br/>

<button class="btn btn-outline-primary"  id="hbtnn" name="txtbutton" ><a >Find Diet</a></button>



</form>



</div>
</div>
@endsection










