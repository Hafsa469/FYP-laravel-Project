@extends('layout.sehat')
@section('title','Symptoms Form')
@section('contents')

@if (count($errors) > 0)
         <div class = "alert alert-danger" id="errors">
            <ul>
               @foreach ($errors->all() as $error)
                  <li>{{ $error }}</li>
               @endforeach
            </ul>
         </div>
@endif

{{csrf_field()}}


<div class="d_wrapper">
       <div class="d_form-wrapper">
    

{{csrf_field()}}
<table>
<tbody>
<thead>
    
    <th id="head">Search Related To Your Symptoms Experienced</th>
   
</thead>
<?php $i=0 ?>
    @foreach($result_ar as $key => $result_ar)
    @if (($key) != 0)
        <tr>
            <td><span id="no"><?php echo $i.")"; $i++; ?></span><span id="data">{{$result_ar}}</span></td>
        </tr>   
    @endif  
    @endforeach
    <tbody>
</table>
<br/><br/>


<form action="{{url('/symptoms')}}" method="POST">
{{csrf_field()}}
<?php if ( ($i-1)> 0){?>
<div>
<label>Select the one From above Symptoms(0 <?php if ( ($i-1)> 0){ echo ("-{".($i-1)."}"); } ?>):  </label>
<select name="choice" id="disease" >
    <?php for ($a=0;$a<($i);$a++){?>
    <option><?php echo ($a); ?></option>
    <?php } ?>
</select>    
</div>
<?php }else{ ?>
<input type="hidden"  value='0' name="choice"   class="doc" />
<?php } ?>

<br>
<div> 
<label>From How Many Days?</label>

<select  name="days"  id="disease" class="doc">
    <option>1</option><option>2</option><option>3</option><option>4</option><option>5</option>
    <option>6</option><option>7</option><option>8</option><option>9</option><option>10</option>
    <option>11</option><option>12</option><option>13</option><option>14</option><option>15</option>
    <option>16</option><option>17</option><option>18</option><option>19</option><option>20</option>
    <option>21</option><option>22</option><option>23</option><option>24</option><option>25</option>
    <option>26</option><option>27</option><option>28</option><option>29</option><option>30</option>
    <option>31</option><option>32</option><option>33</option><option>34</option><option>35</option>
    <option>36</option><option>37</option><option>38</option><option>39</option><option>40</option>
    <option>41</option><option>42</option><option>43</option><option>44</option><option>5</option>
    <option>46</option><option>47</option><option>48</option><option>49</option><option>50</option>
</select>


</div>
<br/>
<button class="btn btn-outline-primary"  id="e_btn" name="txtbutton" ><a >Submit</a></button>
</form>


</div>
</div>



@endsection