@extends('layout.sehat')
@section('title','Doctor Form')
@section('contents')

{{csrf_field()}}


<div class="d_wrapper">
    <div class="mdp_form-wrapper">
            
            <br>
            @if (count($errors) > 0)
                <div class = "alert alert-danger" id="cerrors">
                    <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                    </ul>
                </div>
            @endif
           
               
             <p><img src="/MyLaravel/Laravel/public/images/doctor.png" id="doutput" width="200" /></p>
             @if(!empty($success))
                <div class="alert alert-success" id="cerrors"> 
                {{ $success}}
                </div>
                <button class="btn btn-info" onclick="back();" style="font-size:17px;font-family: 'Times New Roman', Times, serif; width:200px; height:40px; margin-left:400px; margin-top:10px;" name="txtbutton" ><a >Go Back to previous Page</a></button>
            @endif 
            <form>
            {{csrf_field()}}
              
             
              @foreach($doctor as $key => $doctor)

              @if($key == 0)
              <!-- Example single danger button -->
              <div class="btn-group dropright" style="margin-left: 300px; margin-top:11px;">
              <button type="button" class="btn btn-secondary btn-lg dropdown-toggle" id="write" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Sort the available doctors by their Fee Range  </button>
                     <ul class="dropdown-menu">
                            <li><a href="/MyLaravel/Laravel/public/E-SEHAT/0/{{$doctor['speciality']}}/{{$doctor['City']}}/fee">0-1000</a></li>
                            <li><a href="/MyLaravel/Laravel/public/E-SEHAT/1000/{{$doctor['speciality']}}/{{$doctor['City']}}/fee">1000-2000</a></li>
                            <li><a href="/MyLaravel/Laravel/public/E-SEHAT/2000/{{$doctor['speciality']}}/{{$doctor['City']}}/fee">2000-3000</a></li>
                            <li><a href="/MyLaravel/Laravel/public/E-SEHAT/3000/{{$doctor['speciality']}}/{{$doctor['City']}}/fee">3000-4000</a></li>
                            <li><a href="/MyLaravel/Laravel/public/E-SEHAT/4000/{{$doctor['speciality']}}/{{$doctor['City']}}/fee">4000-5000</a></li>
                     </ul>
              </div>
              
              <a href="/MyLaravel/Laravel/public/E-SEHAT/low/{{$doctor['speciality']}}/{{$doctor['City']}}/fee"><button class="btn btn-success"  style="font-size:17px;font-family: 'Times New Roman', Times, serif; width:250px; height:40px; margin-left:200px; margin-top:10px;" name="txtbutton" >Sort Fees From Low to High</button></a>
              <a href="/MyLaravel/Laravel/public/E-SEHAT/high/{{$doctor['speciality']}}/{{$doctor['City']}}/fee"><button class="btn btn-info" style="font-size:17px;font-family: 'Times New Roman', Times, serif; width:250px; height:40px; position:relative; left:100px; top:5px;" name="txtbutton" >Sort Fees From High to Low</button></a>
              
              <br>
              @endif

              <div class="clinic">
              <br><br>
              <div>
                     <p><img src="/MyLaravel/Laravel/storage/uploads{{$doctor['Image']}}" id="output" width="200" /></p>
              </div>
              <div style=" position:relative; left:250px; bottom:200px;">
                     <span class="red1"><u>{{$doctor["name"]}}</u></span><br>
                     <span class="red2">{{$doctor["designation"]}}<span class="red2">,<span><span class="red2">{{$doctor["speciality"]}}</span></span><br>
                     <span class="red1">{{$doctor["Organization"]}}<span class="red1">,<span><span class="red1">{{$doctor["Location"]}}</span></span><br>
                     <span class="red1">{{$doctor["City"]}}<span class="red1">, Experience<span><span class="red1">{{$doctor["Experience_Time"]}}</span></span>  
                     <br><span class="red2">Fees: {{$doctor["Fees"]}}</span>
              </div>
              <div style=" position:relative; left:390px; bottom:350px;">
              <button class="btn btn-outline-primary"  id="e_btnn" name="txtbutton" ><a href='/MyLaravel/Laravel/public/E-SEHAT/{{$doctor["id"]}}/clinic'>Book In-Clinic Appointment</a></button>
              <button class="btn btn-outline-primary"  id="e_btnn" name="txtbutton" ><a href='/MyLaravel/Laravel/public/E-SEHAT/{{$doctor["id"]}}/video'>Book Video Consultation</a></button>
              <button class="btn btn-outline-primary"  id="e_btnn" name="txtbutton" ><a href='/MyLaravel/Laravel/public/E-SEHAT/{{$doctor["id"]}}/viewDocprofile'>View Profile</a></button>
              </div>
              <p class="fff" style=" position:relative; left:2px; bottom:240px; right:25px;"><span class="red2" style="font-size:20px;">Message: </span>{{$doctor["message"]}}</p>
             
   
              </div>
             
              @endforeach
              </form>
    </div>
</div>       

<script>
function back()
{
    history.go(-1);
}

</script>


@endsection