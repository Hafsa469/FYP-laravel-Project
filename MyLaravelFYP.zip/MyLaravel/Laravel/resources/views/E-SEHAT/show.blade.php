@extends('layout.sehat')
@section('title','Health & Nutrition Form')
@section('contents')


<div class="wrapper">
       <div class="nform-wrapper">
       {{csrf_field()}}
<table id="form">
<tbody>
<thead>
    
    <th>Diet Plans</th>
   
</thead>
<?php $i=1 ?>
    @foreach($data as $key => $data)
        @if (($data) != "")
        <tr>
            @if (($key) == 0)
            <th>Disease:<span id="data2">{{$data}}</span></th>
            
            @elseif (($key) != 0)
            <td><span id="no"><?php echo $i.")"; $i++; ?></span><span id="data">{{$data}}<?php echo "." ?></span></td>
            @endif
        </tr>
        
        @endif
    @endforeach
    <tbody>
</table>

<br><br>
<div>
<label id="sat">Are You Satisfied with this Diet Plan?</label><br/>
<label id="sat">If No, You can Consult a Dietitian/Nutritionist!</label><br/>
</div>
<br/>
<button class="btn btn-secondary btn-lg"  id="dieti" name="txtbutton" ><a href='/MyLaravel/Laravel/public/E-SEHAT/searchSpecialist'>Consult Nutritionist</a></button>

<br/>

</div>
</div>
@endsection