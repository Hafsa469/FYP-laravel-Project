@extends('layout.sehat')
@section('title','Login Form')
@section('contents')



{{csrf_field()}}


<div class="d_wrapper">
       <div class="d_form-wrapper">
    
<form action="{{url('/diagonose1')}}" method="POST">
@if (count($errors) > 0)
         <div class = "alert alert-danger" id="cerrors">
            <ul>
               @foreach ($errors->all() as $error)
                  <li>{{ $error }}</li>
               @endforeach
            </ul>
         </div>
@endif
{{csrf_field()}}
<div class="space"></div>
<div>
<label>Patient Name:</label>
<input type="text" size="10" name="name" placeholder="Your Name" class="doc" />

<label>Sex:</label>
<select name="gender" class="doc1">
<option>Male</option>
<option>Female</option>
</select>

</div>
<br/>
<div> 
<label>Patient Age:</label>
<input type="number" size="10" min=1 max=150 name="age"  class="doc" />
</div>
<br/>

<div> 
<label>Enter any Symptom you are experencing:</label>
<input type="text" pattern="[a-z]*" name="symptom" placeholder="symptom" class="doc" />
</div>
<br/>
<button class="btn btn-outline-primary"  id="ebtn" name="txtbutton" ><a >Submit</a></button>


</form>


</div>
</div>



@endsection