@extends('layout.doctor')
@section('title','Doctor Form')
@section('contents')

{{csrf_field()}}


<div class="d_wrapper">
    <div class="mdp_form-wrapper">
                
                <br><br>
                
              <form>
              {{csrf_field()}}
              <h1 style="text-align:center;"><u>Your Reviews</u></h1>
              @foreach($reviews as $key => $reviews)
              <div class="clinics">
                <br><br>
                <div>
                    <label  class="ff">Name:</label>
                    <span class="fff">{{$reviews['name']}}</span><br>
                </div>
                <div>
                    <label  class="red2">Review:</label><br/>
                    <textarea id="mess" rows=5 cols=120 name="experience" placeholder="Type your Experience here " readonly style="margin-left:10px;">{{$reviews['reviews']}}</textarea>
                </div>
              </div>
             
              @endforeach
              </form>

    </div>
</div>       




@endsection