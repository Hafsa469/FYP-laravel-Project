@extends('layout.sehat')
@section('title','Login Form')
@section('contents')

{{csrf_field()}}


<div class="wrap">
       <div class="ddform-wrapper">
    
<form action="{{url('/diagonosis')}}" method="POST">
{{csrf_field()}}
<div>
<label id="click">For Disease Diagonosis Just Click on the Start button below:</label><br/>
</div>
<br/>
<button class="btn btn-outline-primary"  id="hbtnn" name="txtbutton" ><a >Start</a></button>
</form>



</div>
</div>



@endsection