@extends('layout.sehat')
@section('title','Login Form')
@section('contents')




<div class="wrap">
       <div class="ddform-wrapper">
    
<form action="" method="POST">
{{csrf_field()}}
<div>
<label id="click">For Disease Diagonosis You must have to Login First:</label><br/>
</div>
<br/>
<button class="btn btn-outline-primary"  id="hbtnn" name="txtbutton" ><a href="{{url('/E-SEHAT/login')}}">Login</a></button>
<br/>
<div>
<label id="click">If You don't have any account..Must Create it First:</label><br/>
</div>
<br/>
<button class="btn btn-outline-primary"  id="hbtnn" name="txtbutton" ><a href="{{url('/E-SEHAT/UserRegister')}}">Create Account</a></button>
</form>



</div>
</div>



@endsection