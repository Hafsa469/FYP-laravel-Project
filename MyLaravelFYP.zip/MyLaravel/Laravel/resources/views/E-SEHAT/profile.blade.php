@extends('layout.doctor')
@section('title','Doctor Profile Form')
@section('contents')

{{csrf_field()}}


<div class="d_wrapper">
    <div class="mdp_form-wrapper">
                <h1 class="hdng"> Your Profile </h1>
                <br><br>
                @if(session()->has('success'))
                    <div class="alert alert-success" id="success" >
                        {{ session()->get('success') }}
                    </div>
                @endif 
              <form>
              {{csrf_field()}}
              
              
              
              <div>
                     <p><img src="/MyLaravel/Laravel/storage/uploads{{$doctor['Image']}}" id="output" width="200" /></p>
              </div>
              <div class="info">
                     <span class="ffi"><u>{{$doctor["name"]}}</u></span><br>
                     <span class="red2">{{$doctor["designation"]}}<span class="red2">,<span><span class="red2">{{$doctor["speciality"]}}</span></span><br>
                     <span class="ffi">{{$doctor["phone"]}}</span><br>
                     <span class="ffi">{{$doctor["email"]}}</span>
              </div>
              <div>
                <label  class="ff">Personel Information:</label><br/>
                <textarea id="mess" rows=5 cols=120 name="about" placeholder="Type about yourself here " readonly>{{$doctor['About']}}</textarea>
              </div>
              <div>
                <label  class="ff">Qualification:</label><br/>
                <textarea id="mess" rows=5 cols=120 name="qualification" placeholder="Type your Qualification here " readonly >{{$doctor['Qualification']}}</textarea>
              </div>
              <div>
                <label  class="ff">Services:</label><br/>
                <textarea id="mess" rows=5 cols=120 name="services" placeholder="Type your Services here " readonly>{{$doctor['Services']}}</textarea>
              </div>
              <div>
                <label  class="ff">Working Experience:</label><br/>
                <textarea id="mess" rows=5 cols=120 name="experience" placeholder="Type your Experience here " readonly>{{$doctor['Experience']}}</textarea>
              </div>

              <div>
                <label  class="ff">Experienced Period:</label><span class="fff">{{$doctor['Experience_Time']}}</span>
              </div>

              <div class="clinic">
              <br>
                     <h2>Organization Address</h2>
                     <div>
                            <label  class="ff">Working Organization:</label>
                            <span class="fff">{{$doctor['Organization']}}</span><br>
                            <label  class="ff">Location:</label>
                            <span class="fff">{{$doctor['Location']}}</span><br>
                            <label  class="ff">City:</label>
                            <span class="fff">{{$doctor['City']}}</span>
                     </div>
              <br>
              </div>
              
              <div class="clinic">
              <br>
                     <h2>In-Clinic Appointement</h2>
                     <div>
                            <br>
                            <img src="/MyLaravel/Laravel/public/images/video.png" class="image" /> <br>
                            <label class="ff">Available Days:</label>
                            <span class="red2">{{$doctor['Working_days']}}</span><br>

                            <label class="ff">Available Timings:</label>
                            <span class="fff">{{$doctor['Time']}}</span><br>
                            
                            <label class="ff">Appointement Duration:</label>
                            <span class="fff">{{$doctor['Duration']}}</span><span class="fff">minutes</span>  
                               
                     </div>
                     <div>
                            <label class="ff">Fees:</label>
                            <span class="fff">{{$doctor['Fees']}}</span>
                            
                     </div>

              <br><br>
              </div>
              <div class="video">
              <br>
                     <h2>Video Consultation</h2>
                     <div>
                            <br>
                            <img src="/MyLaravel/Laravel/public/images/clinic.png" class="image" /> <br>
                            <label class="ff">Available Days:</label>
                            <span class="red2">{{$doctor['VWorking_days']}}</span><br>

                            <label class="ff">Available Timings:</label>
                            <span class="fff">{{$doctor['VTime']}}</span><br>
                            <label class="ff">Appointement Duration:</label>
                            <span class="fff">{{$doctor['VDuration']}}</span>   <span class="fff">minutes</span>                          
                     </div>
                     <div>
                            
                            <label class="ff">Fees:</label>
                            <span class="fff">{{$doctor['VFees']}}</span>
                            
                     </div>

              <br>
              </div>
              
              </form>
              <button class="btn btn-outline-success"  id="e_btnn" name="txtbutton" style="margin-left:350px;  width:130px; padding:10px"><a href="{{url('/E-SEHAT/editprofile')}}">Edit Profile</a></button>
              <button class="btn btn-outline-danger"  id="e_btnn" name="txtbutton" style="position:relative; bottom:53px;left:80px; width:130px; padding:10px"><a href="{{url('/E-SEHAT/docReviews')}}">View Reviews</a></button>
            

       


    </div>
</div>       




@endsection