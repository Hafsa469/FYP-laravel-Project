<!DOCTYPE html>
<html>
<head>
    
    <title>App Name - @yield('title')</title>
    <!--
    <link rel="stylesheet" type="text/css" href="{{ URL::to('css/app.css') }}">-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="http://code.jquery.com/jquery-3.3.1.min.js"
      integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
      crossorigin="anonymous">
    </script>
    <style>
    /*login*/
    #cerrors{
        font-family: "Times New Roman", Times, serif;
        font-size:20px;
        border:4px brown solid;
    }
    #errors
    {
        font-family: "Times New Roman", Times, serif;
        position:absolute;
        width:300px;
        left:500px;
        top:550px;
        border:4px brown solid;
    }
    #usererrors
    {
        font-family: "Times New Roman", Times, serif;
        position:absolute;
        width:300px;
        left:900px;
        top:350px;
        border:4px brown solid;
    }
    #error
    {
        font-family: "Times New Roman", Times, serif;
        position:absolute;
        width:300px;
        left:500px;
        top:40px;
        border:4px brown solid;
    }
#disease
{
  font-family: "Times New Roman", Times, serif;
    padding: 10px 350px 10px 5px;
    margin-bottom: 2px;
    margin-right: 10px;
    border-radius: 5px;
    outline:none;
}
input{
    font-family: "Times New Roman", Times, serif;
    padding: 10px 230px 10px 5px;
    margin-bottom: 2px;
    margin-right: 10px;
    border-radius: 5px;
    outline:none;
     
  }
  input::placeholder{
    font-family: "Times New Roman", Times, serif;
  
  }
.wrapper{
    height:100vh;
    width:100%;
    justify-content:center;
    /*background-color: darkcyan;
    background-repeat:no-repeat;
    background-size:100%;*/
    align-items: center;
    display:flex;
    flex-direction:column;
    background-image:url("/MyLaravel/Laravel/public/images/download.jpg");
    background-repeat:no-repeat;
    background-size: cover;
  
  }
  .wrap{
    height:80vh;
    width:100%;
    justify-content:center;
    /*background-color: darkcyan;
    background-repeat:no-repeat;
    background-size:100%;*/
    align-items: center;
    display:flex;
    flex-direction:column;
    background-image:url("/MyLaravel/Laravel/public/images/download.jpg");
    background-repeat:no-repeat;
    background-size: cover;
  
  }
  .form-wrapper{
    
    width:530px;
    height:600px;
    display:flex;
    flex-direction:column;
    padding: 20px 30px;
    border-radius: 10px;
    box-shadow: 0px 10px 50px #555;
    background-color: aliceblue;
    border:4px blue solid;
  
  }
  li{
    font-family: "Times New Roman", Times, serif; 
  }
  label{
    font-family: "Times New Roman", Times, serif;
    font-size: 17px;
    font-weight:lighter;
    margin-top:0px;
    margin-bottom: 1px;
    color: #222;
  }
  #btnn
  {
    width:120px;
    margin-left:150px;
    margin-top:4px;
    display: flex;
    align-items: center;
    flex-direction:column;
    font-family: "Times New Roman", Times, serif;
  }
  #success{
    font-family: "Times New Roman", Times, serif;
    font-weight:bold;
    font-size:20px;
    color:red;
    border:4px darkgreen solid;
  }
  /*doctor login*/
  .d_form-wrapper{
      margin-top:10px;
    width:900px;
    height:900px;
    display:flex;
    flex-direction:column;
    padding: 20px 30px;
    border-radius: 10px;
    box-shadow: 0px 10px 50px #555;
    background-color: aliceblue;
    border:4px blue solid;
  
  }
  .md_form-wrapper{
      margin-top:10px;
    width:1100px;
    height:4000px;
    display:flex;
    flex-direction:column;
    padding: 20px 30px;
    border-radius: 10px;
    box-shadow: 0px 10px 50px #555;
    background-color: aliceblue;
    border:4px blue solid;
  
  }
  .mdp_form-wrapper{
      margin-top:10px;
    width:1100px;
    height:3500px;
    display:flex;
    flex-direction:column;
    padding: 20px 30px;
    border-radius: 10px;
    box-shadow: 0px 10px 50px #555;
    background-color: aliceblue;
    border:4px blue solid;
  
  }
  #output{
    margin-left:50px;
  }
  .d_wrapper{
    height:100%;
    width:100%;
    justify-content:center;
    /*background-color: darkcyan;
    background-repeat:no-repeat;
    background-size:100%;*/
    align-items: center;
    display:flex;
    flex-direction:column;
    background-image:url("/MyLaravel/Laravel/public/images/images.jpg");
    background-repeat:no-repeat;
    background-size: cover;
    image-rendering: -webkit-optimize-contrast;
  
  }
  #md{
    margin-left: 30px;
    width:120px;
    font-family: "Times New Roman", Times, serif;
    color:white;
    font-size:17px;
  }
  .doc{

    font-family: "Times New Roman", Times, serif;
    height:40px;
    margin-bottom: 2px;
    border-radius: 5px;
    outline:none; 
  }
  .space{
      margin-top:70px;
  }
  .doc::placeholder{
    font-family: "Times New Roman", Times, serif; 
  }
  #mess{
    font-family: "Times New Roman", Times, serif; 
  }
  #d_btnn
  {
    width:130px;
    margin-left:450px;
    margin-top:2px;
    padding:10px;
    display: flex;
    align-items: center;
    flex-direction:column;
    font-size:20px;
    font-family: "Times New Roman", Times, serif;
  }

  #style{
    font-family: "Times New Roman", Times, serif;
    height:70px;
    background-color:darkblue;
    color:white;
    margin-bottom:0px;
    
   } 

#col{
    color:white;
    margin-right:50px;
    font-size: 20px;
    border:1px solid black;
    padding:6px;
    
}
li a:hover{
  color:white;
}
#dist{
    padding-right:5px;
}
.img{
    background-image:url("./images/images.jpg");
    background-repeat:no-repeat;
    background-size: cover;
    width:100%;
    height:600px;
   
}
#para{
    font-family: Impact, Charcoal, sans-serif;
    font-weight: bold;
    color:black;
    font-size:35px;
    position: absolute;
    top:300px;
    left:100px;
}
#para1{
    font-family: Impact, Charcoal, sans-serif;
    color:darkblue;
    font-size:35px;
    position: absolute;
    top:340px;
    left:100px;
}
#para2{
    font-family: "Times New Roman", Times, serif;
    font-weight: normal;
    color:black;
    font-size:15px;
    position: absolute;
    top:390px;
    left:100px;
}
#sbtn{
    width:120px;
    position: absolute;
    top:440px;
    left:100px;
    display: flex;
    align-items: center;
    flex-direction:column;
    font-family: "Times New Roman", Times, serif;
}
#hbtnn{
  width:120px;
    margin-left:250px;
    margin-top:4px;
    display: flex;
    align-items: center;
    flex-direction:column;
    font-family: "Times New Roman", Times, serif;
}
#lbtn{
    width:120px;
    position: absolute;
    top:440px;
    left:250px;
    display: flex;
    align-items: center;
    flex-direction:column;
    background-color: white;
    font-family: "Times New Roman", Times, serif;
}
Button a:hover {
  color:darkblue;
}
.imge{
    margin-left:60px;
}
#icon{
    margin-left:900px;
    height:30px;
    position:absolute;
    top:40px;
    left:240px;
}
.search{
    margin-left:450px;
}
/*Contact*/
.c_form-wrapper{
      margin-top:10px;
    width:900px;
    height:600px;
    display:flex;
    flex-direction:column;
    padding: 20px 30px;
    border-radius: 10px;
    box-shadow: 0px 10px 50px #555;
    background-color: aliceblue;
    border:4px blue solid;
  
  }
  .c_wrapper{
    height:120vh;
    width:100%;
    justify-content:center;
    align-items: center;
    display:flex;
    flex-direction:column;
    background-image:url("/MyLaravel/Laravel/public/images/images.jpg");
    background-repeat:no-repeat;
    background-size: cover;
    
  
  }
  .ad_form-wrapper{
      margin-top:10px;
    width:900px;
    height:200px;
    display:flex;
    flex-direction:column;
    padding: 20px 30px;
    border-radius: 10px;
    box-shadow: 0px 10px 50px #555;
    background-color: aliceblue;
    border:4px blue solid;
  
  }
  #ph,#em,#add{
    font-family: "Times New Roman", Times, serif;
      background-color:white;
  }
  .lb{
      font-weight:bold;
  }
  .ddform-wrapper{
    
    width:700px;
    height:300px;
    display:flex;
    flex-direction:column;
    padding: 20px 30px;
    border-radius: 10px;
    box-shadow: 0px 10px 50px #555;
    background-color: aliceblue;
    border:4px blue solid;
  
  }
  .nform-wrapper{
    
    width:1100px;
    height:650px;
    display:flex;
    flex-direction:column;
    padding: 20px 30px;
    border-radius: 10px;
    box-shadow: 0px 10px 50px #555;
    background-color: aliceblue;
    border:4px blue solid;
  
  }
  td{
    font-family: "Times New Roman", Times, serif;
    background-color:white;
    font-size:20px;
  }
  th{
    font-family: "Times New Roman", Times, serif;
    background-color:darkblue;
    color:white;
    font-size:25px;
    text-align:center;
  }
  tr{
    background-color:darkblue;
  }
  #no{
    font-weight:bold;
    font-size:22px;
  }
  #data{
    margin-left:10px;
    margin-right:250px;
    text-align:justify;
    
  }
  #data2{
    margin-left:10px;
    text-align:center;
    
  }
  #click{
    font-family: "Times New Roman", Times, serif;
    color:darkblue;
    font-size:25px;
    font-weight:bold;
    text-align:center;
  }
.doc1{

font-family: "Times New Roman", Times, serif;
height:40px;
width:300px;
margin-bottom: 2px;
border-radius: 5px;
outline:none; 
}
#head{
  font-family: "Times New Roman", Times, serif;
  text-align:center;
  margin-left:100px;
}
#headr{
  margin-top:5px;
  font-family: "Times New Roman", Times, serif;
  text-align:center;
  background-color:White;
  color:darkblue;
}
#headrr{
  margin-top:5px;
  font-family: "Times New Roman", Times, serif;
  text-align:center;
  background-color:darkgreen;
  color:white;
}
#head1{
  text-align:center;
  font-family: "Times New Roman", Times, serif;
    background-color:darkblue;
    color:white;
    font-size:25px;
    text-align:center;
    font-weight:bold;
}
#data1{
    font-family: "Times New Roman", Times, serif;
    margin-left:20px;
    font-weight:bold;
    padding:8px;
    
  }
table{
  
  width:850px;
}
#form{
  width:1030px;
}
#doc2{

font-family: "Times New Roman", Times, serif;
height:40px;
width:250px;
margin-bottom: 2px;
color:blue;
outline:none; 
margin-left:50px
}
.check{
  font-family: "Times New Roman", Times, serif;
  margin-left:5px;
  font-size:18px;
  margin-right:100px;

}
.check1{
  font-family: "Times New Roman", Times, serif;
  margin-left:5px;
  font-size:18px;
  margin-right:78px;

}
.check2{
  font-family: "Times New Roman", Times, serif;
  margin-left:5px;
  font-size:18px;
  margin-right:92px;

}
.check3{
  font-family: "Times New Roman", Times, serif;
  margin-left:5px;
  font-size:18px;
  margin-right:113px;

}
.check4{
  font-family: "Times New Roman", Times, serif;
  margin-left:5px;
  font-size:18px;
  margin-right:96px;

}
.check5{
  font-family: "Times New Roman", Times, serif;
  margin-left:5px;
  font-size:18px;
  margin-right:105px;

}
#out{
  font-weight:bold;
  font-size:25px;
  color:darkblue;
  font-family: "Times New Roman", Times, serif;
  margin-left:800px;
}
h1{
  font-family: "Times New Roman", Times, serif;
  color:darkblue;
}
.hdng{
  text-align:center;

}
.info{
  position:absolute;
  left:400px;
  top:300px;
}
h2{
  text-align:center;
  font-family: "Times New Roman", Times, serif;
  color:darkblue;
  padding-bottom: 5px;
}
.ff{
  font-family: "Times New Roman", Times, serif;
  margin-left:5px;
  font-size:18px;
  font-weight:bold;
}
.red2{
    font-family: "Times New Roman", Times, serif;
    margin-left:5px;
    font-size:18px;
    font-weight:bold;
    color:red;
  }
  .clinics{
  background-color:white;
  margin-top:25px;
  margin-bottom:25px;
  border: 2px groove blue;
  border-radius:5px;

}
.image{
    margin-left:170px;
    width:700px;
    height:100px;
}
.ffi{
  font-family: "Times New Roman", Times, serif;
  margin-left:5px;
  font-size:18px;
  font-weight:bold;
  color:darkblue;
}
.fff{
  font-family: "Times New Roman", Times, serif;
  margin-left:7px;
  font-size:16px;
  text-align:justify;
  
}
.clinic{
  background-color:white;
  margin-top:25px;
  margin-bottom:25px;
  border: 2px groove blue;
  border-radius:5px;

}
.video{
  background-color:white;
  margin-top:25px;
  margin-bottom:25px;
  border: 2px groove blue;
  border-radius:5px;

}
.organ{
  background-color:white;
  margin-top:25px;
  margin-bottom:25px;
  border: 2px groove blue;
  border-radius:5px;

}
#docbtn{
  
  font-size:22px;
  margin-left:100px;
  margin-right:100px;
    display: flex;
    align-items: center;
    flex-direction:column;
    background-color: white;
    font-family: "Times New Roman", Times, serif;
}
#dietbtn{
  margin-left:100px;
  margin-right:100px;
  margin-top:5px;
    font-weight:bold;
    font-size:22px;
    display: flex;
    color:white;
    align-items: center;
    flex-direction:column;
    background-color: darkgreen;
    font-family: "Times New Roman", Times, serif;
}
#e_btnn
  {
    width:130px;
    margin-left:450px;
    margin-top:2px;
    padding:5px;
    display: flex;
    align-items: center;
    flex-direction:column;
    font-size:20px;
    font-family: "Times New Roman", Times, serif;
  }
  #e_btn
  {
    width:130px;
    margin-left:350px;
    margin-top:2px;
    padding:5px;
    display: flex;
    align-items: center;
    flex-direction:column;
    font-size:20px;
    font-family: "Times New Roman", Times, serif;
  }
  #ebtn
  {
    width:150px;
    margin-left:250px;
    margin-top:2px;
    padding:5px;
    display: flex;
    align-items: center;
    flex-direction:column;
    font-size:20px;
    font-family: "Times New Roman", Times, serif;
  }
  .red{
    font-family: "Times New Roman", Times, serif;
    margin-left:5px;
    font-size:18px;
    font-weight:bold;
    color:red;
  }
  .red1{
    font-family: "Times New Roman", Times, serif;
    margin-left:5px;
    font-size:18px;
    font-weight:bold;
    color:darkblue;
  }
    </style>
</head>
<body>
<div>
<img src="/MyLaravel/Laravel/public/images/Capture.PNG" class="imge" />  


<span id="out"><a href="{{url('/E-SEHAT/log')}}">LogOut</a></span>


</div>
<nav class="navbar navbar-expand-sm  navbar-light" id="style">
            
            <div class="container">
                <ul class="navbar-nav right">
                    <li id="col"><i class="fa fa-home"></i> <a href="{{url('/E-SEHAT/doctormenu')}}">Home</a></i> </li>  
                    <li id="col"><a href="{{url('/E-SEHAT/myprofile')}}">Profile</a></li>  
                    <li id="col"><a href="{{url('/E-SEHAT/docClinic')}}">In-Clinic Appointments</a></li>
                    <li id="col"><a href="{{url('/E-SEHAT/docVideo')}}">Video Consultations</a></li>
                    <li id="col"><a href="{{url('/E-SEHAT/doctorcontact')}}">Contact Us</a></li>
                    
                </ul>
              
            </div>
</nav>

    
    @yield('contents')
   
    <!--<p><small>Copyrights&copy; {{date('Y')}}</small></p>-->
    <script src="{{asset('java/app.js')}}"></script>
</body>
</html>