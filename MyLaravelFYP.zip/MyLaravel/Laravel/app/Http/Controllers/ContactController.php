<?php

namespace App\Http\Controllers;
use App\Contact;
use Illuminate\Http\Request;
use Validator;

class ContactController extends Controller
{
    public function contactInfo(Request $request)
    {
        $v = Validator::make($request->all(), [
            'email' => 'required',
            'name' => 'required',
            'phone'=> 'required|min:11|max:11',
            'message' => 'required',
            
        ]);
    
        if ($v->fails())
        {
          
            return redirect()->back()->withErrors($v->errors());
          
        }
        else
        {
            $contact=new Contact();
            $contact->name=request('name');
            $contact->email=request('email');
            $contact->phone=request('phone');
            $contact->message=request('message');
            $created=$contact->save();
            if($created)
            {
            return redirect('E-SEHAT/contact');
            }
           
        }
    }
}
