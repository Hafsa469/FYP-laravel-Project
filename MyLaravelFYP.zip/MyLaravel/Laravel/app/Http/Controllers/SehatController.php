<?php

namespace App\Http\Controllers;
use Session;
use Auth;
use SweetAlert;
use App\Sehat;
use App\Review;
use App\Results;
use App\Booking;
use Illuminate\Http\Request;

use DB;
use Validator;
use Symfony\Component\Process\Process;
use Symfony\Component\Process\Exception\ProcessFailedException;
class SehatController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('E-SEHAT.UserRegister');
    }
    public function login()
    {
        return view('E-SEHAT.login');
    }
    
    public function menu()
    {
        return view('E-SEHAT.menu');
    }
    public function contact()
    {
        return view('E-SEHAT.contact');
    }
    public function nutrition()
    {
        return view('E-SEHAT.nutrition');
    }

    public function parseImport(Request $request)
    {
        $v = Validator::make($request->all(), [
            'disease' => 'required', 
        ]);
    
        if ($v->fails())
        {
            return redirect()->back()->withErrors($v->errors());
        }
        else
        {
            $sehat=new Sehat();
            $sehat->name=request('disease');
            $created=$sehat->name;
            if($created)
            {
                $filename = public_path('file\Nutritionst.csv');
                $row=1;
                $delimiter=',';
                $header = null;
                $data = array();
                if (($handle = fopen($filename, 'r')) !== false)
                {
                    while (($data = fgetcsv($handle, 1000, $delimiter)) !== false)
                    {
                            if($data[0]==$created)
                            {
                            #echo $data[$c] . "<br />\n";
                            return view('E-SEHAT.show',compact('data'));
                            }
      
                    }
                    
                    fclose($handle);
                }
            }                
        }
        return false;
       
    }
  
    public function dietPlans(){
        $created=Session::get('dis');
        $filename = public_path('file\Nutritionst.csv');
        $row=1;
        $delimiter=',';
        $header = null;
        $data = array();
        if (($handle = fopen($filename, 'r')) !== false)
        {
            while (($data = fgetcsv($handle, 1000, $delimiter)) !== false)
            {
                
                if($data[0] == trim($created))
                {
                    #echo $data[$c] . "<br />\n";
                    return view('E-SEHAT.show',compact('data'));
                }
      
            }
                    
            fclose($handle);
        }
        echo "Hafsa";
    }
    public function diagonosis()
    {
        $email=Session::get('email');
        if($email != "")
        {
            #echo $email;
            return view('E-SEHAT.diagonosis');
        }
        else{
            return view('E-SEHAT.askLogin');
        }
        
    }
    public function symdiagonosis(Request $request)
    {
        $sehat=new Sehat();
        $name=request('name');
        $age=request('age');
        $sex=request('gender');
        $disease_input=request('symptom');

        $v = Validator::make($request->all(), [
            'age' => 'required',
            'name' => 'required',
            'gender'=> 'required',
            'symptom'=>'required'
        ]);
    
        if ($v->fails())
        {
            return redirect('E-SEHAT/diagonose1')->withErrors($v->errors()); 
        }
        else
        {
            Session::put('disease_input', $disease_input);
            Session::put('name', $name);
            Session::put('age', $age);
            Session::put('gender', $sex);
            $result = shell_exec("python " . app_path(). "\Http\Controllers\python\symptomchecker.py ". escapeshellarg($disease_input) );
            $result=str_replace(array( '[', ']' ,"'",','), '', $result);
            $result_ar = explode(' ', $result);
            Session::put('results', $result_ar);
            
            #print_r($result_ar);
            #echo $result_ar[2];  
            #if  $result_ar[0]==0
                #echo "Enter Valid Symptom"
            return view('E-SEHAT.showSymptoms',compact('result_ar'));
        }
          
    }
    public function showsymptoms(Request $request)
    {
        $sehat=new Sehat();
        $days=request('days');
        $choice=request('choice'); 
        if ($days == "" && $choice == "")
        {
            $choice = Session::get('choice');
            $days = Session::get('days');
        }   
        Session::put('choice', $choice);
        Session::put('days', $days);
        $disease_input = Session::get('disease_input');
        $result = shell_exec("python " . app_path(). "\http\controllers\python\showSymptoms.py ". escapeshellarg($choice). escapeshellarg($days). escapeshellarg($disease_input) );
        $result=str_replace(array( '[', ']' ,"'",','), '', $result);
        #echo $result;
        $result_ar = explode(' ', $result);
            
        return view('E-SEHAT.symptoms',compact('result_ar'));
        
          
    }
    public function results(Request $request)
    {
        $sehat=new Results();
        $name=Session::get('name');
        $email=Session::get('email');
        $age=Session::get('age');
        $gender=Session::get('gender');
        $choices=request('postive');   
        // Filtering the array
        $choices = array_filter($choices);
        $disease_input = Session::get('disease_input');
        $choice = Session::get('choice');
        $days = Session::get('days');
        $expected =implode( ",", $choices ); 
        #$result = shell_exec("python " . app_path(). "\http\controllers\python\output.py ". escapeshellarg($choice). escapeshellarg($days). escapeshellarg($disease_input).escapeshellarg($expected) );
        $result = shell_exec("python " . app_path(). "\http\controllers\python\myoutput.py ". escapeshellarg($choice). escapeshellarg($days). escapeshellarg($disease_input).escapeshellarg($expected) );
        $result_ar = explode('!', $result);
        #print_r($result_ar);
        $outcome=$result_ar[1];
        Session::put('dis',$outcome);
        
            $sehat->name=$name;
            $sehat->email=$email;
            $sehat->age=$age;
            $sehat->gender=$gender;
            $sehat->symptoms=$expected;
            $sehat->disease=$outcome;
            $created=$sehat->save();
            if($created)
            {
            return view('E-SEHAT.outcomes',compact('result_ar'));
            }
          
    }
   
    public function symchecker()
    {
        return view('E-SEHAT.showSymptoms');

    }      
    public function ddiagonosis()
    {
        return view('E-SEHAT.diagonose1');

    }  
    public function d_diagonosis()
    {
    
        return view('E-SEHAT.diagonose1');
    
        
    }
    public function symptoms()
    {
        return view('E-SEHAT.symptoms');
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       
            $v = Validator::make($request->all(), [
                'email' => 'required',
                'name' => 'required',
                'phone'=> 'required|min:11|max:11',
                'password'=>'required|min:6|max:6'
            ]);
        
            if ($v->fails())
            {  
                return redirect()->back()->withErrors($v->errors());
            }
            else
            {
                $sehat=new Sehat();
                $sehat->name=request('name');
                $sehat->email=request('email');
                $sehat->phone=request('phone');
                $sehat->password=request('password');
                $created=$sehat->save();
                if($created)
                {
                    #SweetAlert::success('Thank You!', 'You are now a new member');
                    return redirect('E-SEHAT/login')->with('success', 'Thank You!  You are now a New Member');
                }
               
            }
       
    }
    public function logs(Request $request)
    {
        $v = Validator::make($request->all(), [
            'email' => 'required',
            'password'=>'required'
        ]);
    
        if ($v->fails())
        {
            return redirect()->back()->withErrors($v->errors()); 
        }
        else
        {
            $sehat=new Sehat();
            $sehat->email=request('email');
            $sehat->password=request('password');
            $data=DB::select( 'select id from sehats where email=? and password=?' ,[$sehat->email,$sehat->password]);
            if(count($data))
            {
                Session::put('email', $sehat->email);
                $myArray = json_decode(json_encode($data), true);
                  
                Session::put('logid', $myArray[0]['id']);
                //print_r($myArray[0]['id']);
                #echo "Hey!! you are login!";
                return view('E-SEHAT.menu');
            }
            
            else
            {
                $datas=DB::select( 'select id from doctors where email=? and password=?' ,[$sehat->email,$sehat->password]);
                if(count($datas))
                {
                    Session::put('email', $sehat->email);
                    $myArray = json_decode(json_encode($datas), true);
                   // print_r($myArray);
                    
                    Session::put('key', $myArray[0]['id']);
                    return view('E-SEHAT.doctormenu');
                }
                else{
                    return redirect('E-SEHAT/login')->with('error', 'Your Email/Password is incorrect!!');
                }
                
            }
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Sehat  $sehat
     * @return \Illuminate\Http\Response
     */
    public function showDoc(Sehat $sehat)
    {
        $doctor=$datas=DB::select( 'select * from doctors inner join profiles on doctors.id=profiles.id');
        $myArray = json_decode(json_encode($doctor), true);
        if (!count($doctor ))
        {
            return view('E-SEHAT.ourdoctor')->with('doctor',$myArray)->with('success', 'No Doctors are available in ths city!');
        }
        //print_r($myArray[0]);
        return view('E-SEHAT.ourdoctor',['doctor'=>$myArray]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Sehat  $sehat
     * @return \Illuminate\Http\Response
     */
    public function edit(Sehat $sehat)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Sehat  $sehat
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Sehat $sehat)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Sehat  $sehat
     * @return \Illuminate\Http\Response
     */
    public function destroy(Booking $b,$value)
    {
        echo $value;
        $doctor=DB::select( 'delete from  bookings where booking_id=?',[$value]);
        return redirect()->back()->with('success', 'Remove Successfully!!  ');
    }
    
    
    public function details(Request $request,$value )
    {
        
            
        $choice = Session::get('choice');
        $days = Session::get('days');
            if($value)
            {
                $filename = public_path('file\symptoms_details.csv');
                $row=1;
                $delimiter=',';
                $header = null;
                $data = array();
                if (($handle = fopen($filename, 'r')) !== false)
                {
                    while (($data = fgetcsv($handle, 1000, $delimiter)) !== false)
                    {
                            if($data[0] == $value)
                            {
                            #echo $data[$c] . "<br />\n";
                            return view('E-SEHAT.symptomDetails',compact('data'));
                            }
      
                    }
                    
                    fclose($handle);
                }
            }                 
        
        
          
    }
    public function getLogout(){
        Auth::logout();
        Session::flush();
        return redirect('E-SEHAT/menu');
    }

    public function docProfile()
    {
        return view('E-SEHAT/doctorProfile');
    }
    public function viewprofile(Request $request,$value )
    {
        
        $id = $value;
        
        $doctor=$datas=DB::select( 'select * from doctors inner join profiles on doctors.id=profiles.id');
        $myArray = json_decode(json_encode($doctor), true);
        Session::put('value', $myArray[$id]["id"]);
        $duration=$myArray[$id]["Duration"];
        $data=$myArray[$id]["Time"];
        $start=strtok( $data, '-' );
        $end=substr($data, strpos($data, "-") + 1);
        //$new=date('h:i a', strtotime('+'.$duration.'minutes', strtotime($start)));
        $time=array();
        $new=$start;
        $i=0;
        while( $new != $end)
        {
            $time[$i]=$new;   
            $new=date('h:i a', strtotime('+'.$duration.'minutes', strtotime($new)));
            $i++;
               
        }
        $myArray[$id]['TimeArray']=implode( ",",$time );

        
        $duration=$myArray[$id]["VDuration"];
        $data=$myArray[$id]["VTime"];
        $start=strtok( $data, '-' );
        $end=substr($data, strpos($data, "-") + 1);
        //$new=date('h:i a', strtotime('+'.$duration.'minutes', strtotime($start)));
        $time=array();
        $new=$start;
        $i=0;
        while( $new != $end)
        {
            $time[$i]=$new;   
            $new=date('h:i a', strtotime('+'.$duration.'minutes', strtotime($new)));
            $i++;
               
        }
        //print_r($time);
        $myArray[$id]['VTimeArray']=implode( ",",$time );
       //print_r($myArray[$id]);
       //print_r($myArray[0][2]);
        return view('E-SEHAT.viewprofile',['doctor'=>$myArray[$id]]);
          
    }
    public function clinic(Request $request,$value )
    {
        
        $id = "0";
        $doctor=$datas=DB::select( 'select * from doctors inner join profiles on doctors.id=profiles.id and doctors.id=?',[$value]);
        $myArray = json_decode(json_encode($doctor), true);
        $duration=$myArray[$id]["Duration"];
        $data=$myArray[$id]["Time"];
        $start=strtok( $data, '-' );
        $end=substr($data, strpos($data, "-") + 1);
        //$new=date('h:i a', strtotime('+'.$duration.'minutes', strtotime($start)));
        $time=array();
        $new=$start;
        $i=0;
        while( $new != $end)
        {
            $time[$i]=$new;   
            $new=date('h:i a', strtotime('+'.$duration.'minutes', strtotime($new)));
            $i++;
               
        }
        $myArray[$id]['TimeArray']=implode( ",",$time );
        return view('E-SEHAT.clinic',['doctor'=>$myArray[$id]]);
          
    }
    public function video(Request $request,$value )
    {
        
        $id = "0";
        $doctor=$datas=DB::select( 'select * from doctors inner join profiles on doctors.id=profiles.id and doctors.id=?',[$value]);
        $myArray = json_decode(json_encode($doctor), true);
        $duration=$myArray[$id]["VDuration"];
        $data=$myArray[$id]["VTime"];
        $start=strtok( $data, '-' );
        $end=substr($data, strpos($data, "-") + 1);
        //$new=date('h:i a', strtotime('+'.$duration.'minutes', strtotime($start)));
        $time=array();
        $new=$start;
        $i=0;
        while( $new != $end)
        {
            $time[$i]=$new;   
            $new=date('h:i a', strtotime('+'.$duration.'minutes', strtotime($new)));
            $i++;
               
        }
        $myArray[$id]['VTimeArray']=implode( ",",$time );
        //print_r($myArray[$id]['TimeArray']);
        //print_r($myArray[$id]);
        return view('E-SEHAT.video',['doctor'=>$myArray[$id]]);
          
    }
    public function reviews(Request $request)
    {
        $v = Validator::make($request->all(), [
            'rname' => 'required',
            'reviews'=>'required'
        ]);
    
        if ($v->fails())
        {
            return redirect()->back()->withErrors($v->errors()); 
        }
        else
        {
            $sehat=new Review();
            $value = Session::get('value');
            $sehat->doctor_id=$value;
            $sehat->name=request('rname');
            $sehat->reviews=request('reviews');
            $created=$sehat->save();
            if($created)
            {
            
                return redirect()->back()->with('success', 'Thank You For your Review!  ');
            }
            
        }
      
    }
    public function bookvideo(Request $request )
    {
        $valid = Session::get('email');
        if($valid == "")
        {
            return redirect()->back()->with('success', 'You have to login first!  ');
        }
        $v = Validator::make($request->all(), [
            'name' => 'required',
            'phone'=>'required',
            'VselectedDate' => 'required',
            'VselectedTime'=>'required'
        ]);
    
        if ($v->fails())
        {
            return redirect()->back()->withErrors($v->errors()); 
        }
        else
        {
            $id=request('id');
            $day=date("l", strtotime(request('VselectedDate')));
            $date=request('VselectedDate');
            $time=date("h:i a", strtotime(request('VselectedTime')));
            $warr=explode(',', request('working'));
            $co=0;
            for($i=0;$i<count($warr);$i++)
            {
                if($warr[$i] == $day)
                {
                    $co=1;
                    break;
                }
            }
            if($co == 0)
            {
                return redirect()->back()->with('success', 'Please Select among available Days!!  '); 
            }
            echo $time,request('tarray');
            $arr=explode(',', request('tarray'));
            $con=0;
            for($i=0;$i<count($arr);$i++)
            {
                if($arr[$i] == $time)
                {
                    $con=1;
                    break;
                }
            }
            if($con == 0)
            {
                return redirect()->back()->with('success', 'Please Select among available Time!!  '); 
            }

            $doctor=DB::select( 'select * from  bookings where doctor_id=? and date=? and time=?',[$id,$date,$time]);
            $myArray = json_decode(json_encode($doctor), true);
            if (!empty($myArray))
            {
                return redirect()->back()->with('success', 'Please Select another time. This time is already booked!  ');
            }

            $sehat=new Booking();
            $sehat->doctor_id=$id;
            $sehat->user_id=Session::get('logid');
            $sehat->bname=request('name');
            $sehat->bphone=request('phone');
            $sehat->date=request('VselectedDate');
            $sehat->time=date("h:i a", strtotime(request('VselectedTime'))); 
            $sehat->day=$day;
            $sehat->type="video";
            $created=$sehat->save();
            if($created)
            {
            
                return redirect()->back()->with('success', 'Thank You For your Booking!  ');
            }
            
        }
          
    }
    public function bookclinic(Request $request )
    {
        
        $valid = Session::get('email');
        if($valid == "")
        {
            return redirect()->back()->with('success', 'You have to login first!  ');
        }
        
        $v = Validator::make($request->all(), [
            'name' => 'required',
            'phone'=>'required',
            'selectedDate' => 'required',
            'selectedTime'=>'required'
        ]);
    
        if ($v->fails())
        {
            return redirect()->back()->withErrors($v->errors()); 
        }
        else
        {
            $value=request('id');
            $day=date("l", strtotime(request('selectedDate')));
            $date=request('selectedDate');
            $time=date("h:i a", strtotime(request('selectedTime')));
            $warr=explode(',', request('cworking'));
            $co=0;
            for($i=0;$i<count($warr);$i++)
            {
                if($warr[$i] == $day)
                {
                    $co=1;
                    break;
                }
            }
            if($co == 0)
            {
                return redirect()->back()->with('success', 'Please Select among available Days!!  '); 
            }

            $arr=explode(',', request('tcarray'));
            //echo $time;
            $con=0;
            for($i=0;$i<count($arr);$i++)
            {
                if($arr[$i] == $time)
                {
                    $con=1;
                    break;
                }
            }
            if($con == 0)
            {
                return redirect()->back()->with('success', 'Please Select among available Time!!  '); 
            }

            $doctor=DB::select( 'select * from bookings where doctor_id=? and date=? and time=?',[$value,$date,$time]);
            $myArray = json_decode(json_encode($doctor), true);
            if (!empty($myArray))
            {
                return redirect()->back()->with('success', 'Please Select another time. This time is already booked!  ');
            }
            $sehat=new Booking();
            $sehat->doctor_id=$value;
            $sehat->user_id=Session::get('logid');
            $sehat->bname=request('name');
            $sehat->bphone=request('phone');
            $sehat->date=request('selectedDate');
            $sehat->time=date("h:i a", strtotime(request('selectedTime'))); 
            $sehat->day=$day;
            $sehat->type="clinic";
            $created=$sehat->save();
            if($created)
            {
            
                return redirect()->back()->with('success', 'Thank You For your Booking!  ');
            }
            
        }
          
    }
    public function userprofile()
    {
        $user_id=Session::get('logid');
        
        $doctor=$datas=DB::select( 'select * from doctors inner join profiles inner join bookings on doctors.id=profiles.id and doctors.id=bookings.doctor_id where user_id=?',[$user_id]);
        $myArray = json_decode(json_encode($doctor), true);
        //print_r($myArray);
        if (!count($doctor ))
        {
            return view('E-SEHAT.userProfile')->with('doctor',$myArray)->with('success', 'You have no appointments!');
        }
        return view('E-SEHAT.userProfile',['doctor'=>$myArray]);

    }
    public function sort($lowerlimit)
    {
        $upperlimit=$lowerlimit+1000;
        $doctor=$datas=DB::select( 'select * from doctors inner join profiles on doctors.id=profiles.id where profiles.Fees between ? AND ?',[$lowerlimit,$upperlimit]);
        $myArray = json_decode(json_encode($doctor), true);
        //print_r($myArray[0]);
        return view('E-SEHAT.ourdoctor',['doctor'=>$myArray]);
        
    }
    public function sortFee($lowerlimit, $speciality, $city)
    {
        if($lowerlimit == "low")
        {
            $doctor=$datas=DB::select( 'select * from doctors inner join profiles on doctors.id=profiles.id where profiles.City=? and doctors.speciality=? order by profiles.Fees ascending',[$city,$speciality]);
            $myArray = json_decode(json_encode($doctor), true);
            return view('E-SEHAT.viewdoctors',['doctor'=>$myArray]);
        }
        else if($lowerlimit == "high")
        {
            $doctor=$datas=DB::select( 'select * from doctors inner join profiles on doctors.id=profiles.id where profiles.City=? and doctors.speciality=? order by profiles.Fees descending',[$city,$speciality]);
            $myArray = json_decode(json_encode($doctor), true);
            return view('E-SEHAT.viewdoctors',['doctor'=>$myArray]);
        }
        else{
            $upperlimit=$lowerlimit+1000;
            $doctor=$datas=DB::select( 'select * from doctors inner join profiles on doctors.id=profiles.id where profiles.City=? and doctors.speciality=? and profiles.Fees between ? AND ?',[$city,$speciality,$lowerlimit,$upperlimit]);
            $myArray = json_decode(json_encode($doctor), true);
            //print_r($myArray[0]);
            if (!count($doctor ))
            {
                return view('E-SEHAT.viewdoctors')->with('doctor',$myArray)->with('success', 'No doctors lie in this range!');
            }
            
            return view('E-SEHAT.viewdoctors',['doctor'=>$myArray]);
        }
        
    }
    public function sortByCity(Request $request)
    {
        $v = Validator::make($request->all(), [

            'search'=>'required'
        ]);
    
        if ($v->fails())
        {
            $doctor=$datas=DB::select( 'select * from doctors inner join profiles on doctors.id=profiles.id');
            $myArray = json_decode(json_encode($doctor), true);
            return view('E-SEHAT.ourdoctor')->with('doctor',$myArray)->with('success', 'Must Enter the city to get the required results!');;
        }
        else
        {
        $city=request('search');
        $doctor=$datas=DB::select( 'select * from doctors inner join profiles on doctors.id=profiles.id where doctors.city=?',[$city]);
        $myArray = json_decode(json_encode($doctor), true);
        if (!count($doctor ))
        {   
            return view('E-SEHAT.viewdoctors')->with('doctor',$myArray)->with('success', 'No Doctors are available in ths city!');
        }
        //echo "hafsa";
        return view('E-SEHAT.viewdoctors',['doctor'=>$myArray]);
        }
        
    }
   
    public function sortCity($city)
    {
        
        if($city != "0"){
        $doctor=$datas=DB::select( 'select * from doctors inner join profiles on doctors.id=profiles.id where profiles.City=?',[$city]);
        $myArray = json_decode(json_encode($doctor), true);
        if (!count($doctor ))
        {   
            return view('E-SEHAT.ourdoctor')->with('doctor',$myArray)->with('success', 'Such Doctors are not available now!');
        }
            return view('E-SEHAT.ourdoctor',['doctor'=>$myArray]);
        }
        else
        {
            $doctor=$datas=DB::select( 'select * from doctors inner join profiles on doctors.id=profiles.id');
            $myArray = json_decode(json_encode($doctor), true);
            if (!count($doctor ))
            {   
                return view('E-SEHAT.ourdoctor')->with('doctor',$myArray)->with('success', 'Such Doctors are not available now!');
            }
            return view('E-SEHAT.ourdoctor',['doctor'=>$myArray]);
        }
    }
    public function sortSpecility($speciality)
    {
        if($speciality != "0"){
        $doctor=$datas=DB::select( 'select * from doctors inner join profiles on doctors.id=profiles.id where doctors.speciality=?',[$speciality]);
        $myArray = json_decode(json_encode($doctor), true);
        if (!count($doctor ))
        {   
            return view('E-SEHAT.ourdoctor')->with('doctor',$myArray)->with('success', 'Such Specialist are not available now!');
        }
        return view('E-SEHAT.ourdoctor',['doctor'=>$myArray]);
        }
        else
        {
            $doctor=$datas=DB::select( 'select * from doctors inner join profiles on doctors.id=profiles.id');
            $myArray = json_decode(json_encode($doctor), true);
            if (!count($doctor ))
            {   
                return view('E-SEHAT.ourdoctor')->with('doctor',$myArray)->with('success', 'Such Specialist are not available now!');
            }
            return view('E-SEHAT.ourdoctor',['doctor'=>$myArray]);
        }
    }
    public function sortDisease($disease)
    {
    
        $doctor=$datas=DB::select( 'select * from doctors inner join profiles on doctors.id=profiles.id where doctors.speciality=?',[$disease]);
        $myArray = json_decode(json_encode($doctor), true);
        if (!count($doctor ))
        {   
            return view('E-SEHAT.ourdoctor')->with('doctor',$myArray)->with('success', 'Such Doctors are not available now!');
        }
        return view('E-SEHAT.ourdoctor',['doctor'=>$myArray]);
    }
    public function selectdoc(Request $request)
    {
    
        
        $v = Validator::make($request->all(), [
            'city' => 'required',
            'search'=>'required'
        ]);
    
        if ($v->fails())
        {
            return redirect()->back()->withErrors($v->errors()); 
        }
        else
        {
            $city=request('city');
            $mychoice=request('search');
            if($mychoice == "Dietitian" || $mychoice == "Nutritionist" || $mychoice == "Dietitian/Nutritionist" )
            {
                $doctor=$datas=DB::select( 'select * from doctors inner join profiles on doctors.id=profiles.id where profiles.City=? and doctors.speciality in (?,?,?)',[$city,"Nutritionist","Dietitian","Dietitian/Nutritionist"]);
                $myArray = json_decode(json_encode($doctor), true);
                if (!count($doctor ))
                {   
                    return view('E-SEHAT.ourdoctor')->with('doctor',$myArray)->with('success', 'Such Specialists are not available now!');
                }
                return view('E-SEHAT.viewdoctors',['doctor'=>$myArray]);
            }
            $doctor=$datas=DB::select( 'select * from doctors inner join profiles on doctors.id=profiles.id where profiles.City=? and doctors.speciality=?',[$city,$mychoice]);
            $myArray = json_decode(json_encode($doctor), true);
            if (!count($doctor ))
            {   
                return view('E-SEHAT.ourdoctor')->with('doctor',$myArray)->with('success', 'Such Doctors are not available now!');
            }
            return view('E-SEHAT.viewdoctors',['doctor'=>$myArray]);
        }
    }

    public function MyDocprofile(Request $request,$value )
    {
        
        $id = "0";
        
        $doctor=$datas=DB::select( 'select * from doctors inner join profiles on doctors.id=profiles.id where doctors.id=?',[$value]);
        $myArray = json_decode(json_encode($doctor), true);
        //Session::put('value', $myArray[$id]["id"]);
        $duration=$myArray[$id]["Duration"];
        $data=$myArray[$id]["Time"];
        $start=strtok( $data, '-' );
        $end=substr($data, strpos($data, "-") + 1);
        $time=array();
        $new=$start;
        $i=0;
        while( $new != $end)
        {
            $time[$i]=$new;   
            $new=date('h:i a', strtotime('+'.$duration.'minutes', strtotime($new)));
            $i++;
               
        }
        $myArray[$id]['TimeArray']=implode( ",",$time );
        $duration=$myArray[$id]["VDuration"];
        $data=$myArray[$id]["VTime"];
        $start=strtok( $data, '-' );
        $end=substr($data, strpos($data, "-") + 1);
        $time=array();
        $new=$start;
        $i=0;
        while( $new != $end)
        {
            $time[$i]=$new;   
            $new=date('h:i a', strtotime('+'.$duration.'minutes', strtotime($new)));
            $i++;
               
        }
        //print_r($time);
        $myArray[$id]['VTimeArray']=implode( ",",$time );
        //print_r($myArray[$id]);
       //print_r($myArray[0][2]);
        return view('E-SEHAT.viewprofile',['doctor'=>$myArray[$id]]);
          
    }

    public function searchSpecialist()
    {
        $doctor=$datas=DB::select( 'select * from doctors inner join profiles on doctors.id=profiles.id where doctors.speciality=? or doctors.speciality=? or doctors.speciality=?',["Nutritionist","Dietitian","Dietitian/Nutritionist"]);
        $myArray = json_decode(json_encode($doctor), true);
        if (!count($doctor ))
        {   
            return view('E-SEHAT.ourdoctor')->with('doctor',$myArray)->with('success', 'Such Specialists are not available now!');
        }
        return view('E-SEHAT.ourdoctor',['doctor'=>$myArray]);
    }
}

