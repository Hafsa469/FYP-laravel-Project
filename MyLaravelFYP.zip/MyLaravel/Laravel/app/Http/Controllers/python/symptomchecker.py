import pandas as pd
from sklearn import preprocessing
from sklearn.ensemble import RandomForestClassifier
from sklearn import metrics
from sklearn.metrics import classification_report
import numpy as np
import csv
import sys
import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)


def diagonosis():
    df = pd.read_csv(r'C:\xampp\htdocs\MyLaravel\Laravel\public\file\Training.csv')
    df_test = pd.read_csv(r'C:\xampp\htdocs\MyLaravel\Laravel\public\file\Testing.csv')
    #mapping strings to numbers
    le = preprocessing.LabelEncoder()
    le.fit(pd.concat([df['prognosis'], df_test['prognosis']]))
    x=df[df.columns.difference(['prognosis'])]
    y=le.fit_transform(df['prognosis'])#tranfer labels into numeric form
    model = RandomForestClassifier()
    #model.fit(x,y)
    model.fit(df[df.columns.difference(['prognosis'])], le.fit_transform(df['prognosis']))
    y_pred=model.predict(df_test[df_test.columns.difference(['prognosis'])])#features of testing

    y_true = le.fit_transform(df_test['prognosis'])#labels of testing
    accuracy=metrics.accuracy_score(y_true, y_pred)
    report=classification_report(y_true, y_pred, target_names=df_test['prognosis'])
    le.inverse_transform(model.classes_)#tranfer into actual names
    feature_names=x   
    def check_pattern(dis_list,inp):

        import re
        pred_list=[]
        ptr=0
        regexp = re.compile(inp)
        for item in dis_list:
            if regexp.search(item):
                pred_list.append(item)
                
        if(len(pred_list)>0):
            return 1,pred_list
        else:
            return ptr,item
    disease_input=sys.argv[1]
    chk_dis=",".join(feature_names).split(",")#separate column names of symptoms
    conf,cnf_dis=check_pattern(chk_dis,disease_input)
    print(conf,cnf_dis)
    return  conf,cnf_dis
    #print(conf,cnf_dis)

diagonosis()



        
  
    

