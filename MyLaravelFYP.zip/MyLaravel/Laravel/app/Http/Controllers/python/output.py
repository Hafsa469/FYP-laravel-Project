import pandas as pd
import pandas as pd
from sklearn import preprocessing
from sklearn.ensemble import RandomForestClassifier
from sklearn import metrics
from sklearn.metrics import classification_report
import numpy as np
import csv
import sys
import warnings
from numpy import array
warnings.filterwarnings("ignore", category=DeprecationWarning)


def diagonosis():
   
    df = pd.read_csv(r'C:\xampp\htdocs\MyLaravel\Laravel\public\file\Training.csv')
    df_test = pd.read_csv(r'C:\xampp\htdocs\MyLaravel\Laravel\public\file\Testing.csv')
    #mapping strings to numbers
    le = preprocessing.LabelEncoder()
    le.fit(pd.concat([df['prognosis'], df_test['prognosis']]))
    x=df[df.columns.difference(['prognosis'])]
    y=le.fit_transform(df['prognosis'])#tranfer labels into numeric form
    model = RandomForestClassifier()
    #model.fit(x,y)
    model.fit(df[df.columns.difference(['prognosis'])], le.fit_transform(df['prognosis']))
    y_pred=model.predict(df_test[df_test.columns.difference(['prognosis'])])#features of testing

    y_true = le.fit_transform(df_test['prognosis'])#labels of testing
    accuracy=metrics.accuracy_score(y_true, y_pred)
    report=classification_report(y_true, y_pred, target_names=df_test['prognosis'])
    le.inverse_transform(model.classes_)#tranfer into actual names
    feature_names=x 
    
    severityDictionary=dict()
    description_list = dict()
    precautionDictionary=dict()



    def check_pattern(dis_list,inp):

        import re
        pred_list=[]
        ptr=0
        regexp = re.compile(inp)
        for item in dis_list:
            if regexp.search(item):
                pred_list.append(item)
                
        if(len(pred_list)>0):
            return 1,pred_list
        else:
            return ptr,item
    
    conf_inp=sys.argv[1]
    arr=conf_inp.split('"')
    conf_inp=arr[0]
    num_days=arr[1]
    disease_input=arr[2]
    symptoms_exp=arr[3]
    symptoms_exp=symptoms_exp.split(',')
    
    chk_dis=",".join(feature_names).split(",")#separate column names of symptoms
    conf,cnf_dis=check_pattern(chk_dis,disease_input)

    def get_disease(model, df, le):
        y_true = model.predict_proba(df)#predict input probabilty for each class
        i = np.argmax(y_true)#choose maximum probability
    #     print(i)
    #     print(model.score())
    #     print(y_true)
    #     print(model.classes_)
    #     print(model.classes_[i])
        disease = le.inverse_transform([model.classes_[i]])
        return disease[0] , y_true[0][i]#disease nd probability
    def filter_cols(model, subsymptoms_df, le):
        y_true = model.predict_proba(subsymptoms_df)
        #find possible diseases
        dis = []
        for i in range(len(y_true[0])):
            if y_true[0][i] > 0:#having probability greater than zero
                dis.append(i)
        disname = le.inverse_transform(dis)
    #     print(dis)
        #print("Possible Diseases: >>> ", disname)
        #for possible diseases find remaining symptoms
        df_fil = df[df['prognosis'].isin(disname)]
        df_fil = df_fil.loc[:, (df_fil != 0).any(axis=0)]
        df_fil = df_fil[df_fil.columns.difference(['prognosis'])]
        #print("Remaining symptoms: ", df_fil.columns.to_list())
        return df_fil.columns
        
    def calc_condition(exp,days):
        with open(r'C:\xampp\htdocs\Laravel\Laravel\public\file\symptom_severity.csv') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            try:
                for row in csv_reader:
                    _diction={row[0]:int(row[1])}
                    severityDictionary.update(_diction)
            except:
                pass
        sum=0
        for item in exp:
            sum=sum+severityDictionary[item]
        if((sum*int(days))/(len(exp)+1)>13):
            print("You should take the consultation from doctor! ")
        else:
            print("It might not be that bad but you should take precautions!")
    
        
    df_copy = df.iloc[0:1,:].copy() #pd.DataFrame().reindex_like(df)(rows,columns)
    df_copy.append(pd.Series(), ignore_index=True)
    for c in df_copy.columns:
        df_copy[c] = 0 #get a row having all symptoms are zero
    df_copy = df_copy[df_copy.columns.difference(['prognosis'])]
    symptoms = df.columns
        

    symptoms_covered=[]
    i = 0
    s = cnf_dis[int(conf_inp)]
    df_copy[s]=1
    symptoms_covered.append(s)
    symptoms = filter_cols(model, df_copy, le)
    for u in symptoms_exp:
        df_copy[u] = 1
    
    ret = get_disease(model, df_copy, le)
    symptoms = filter_cols(model, df_copy, le)
    #print("Suspected disease is : ", ret)
     
    calc_condition(symptoms_exp,num_days)
                
    #Description List
    with open(r'C:\xampp\htdocs\MyLaravel\Laravel\public\file\symptom_Description.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        for row in csv_reader:
            _description={row[0]:row[1]}# {keyword , description}
            description_list.update(_description)
        
    #print(present_disease[0])
    #present=ret[0]+'!'+" "+"!"
    present=ret[0]+'!'
    print(present)
    
    #print(description_list[present_disease[0]])
    #description=description_list[ret[0]]+'!'+" "+"!"
    description=description_list[ret[0]]+'!'
    print(description)

             
                
    #Precaution List
    with open(r'C:\xampp\htdocs\MyLaravel\Laravel\public\file\symptom_precaution.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        for row in csv_reader:
            _prec={row[0]:[row[1],row[2],row[3],row[4]]}
            precautionDictionary.update(_prec)
    precution_list=precautionDictionary[ret[0]]
    precution_list.insert(0,"Precaution Measures")
    #precution_list.append("Precaution Measures")
    #print(precution_list)
    print('!'.join(precution_list))


    
    
    
    

      

    
diagonosis()



        
  
    

